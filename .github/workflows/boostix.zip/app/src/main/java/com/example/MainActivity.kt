package com.example

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.screens.*
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.viewmodel.BoostixViewModel

class MainActivity : ComponentActivity() {

    private val viewModel: BoostixViewModel by viewModels()

    @OptIn(ExperimentalLayoutApi::class)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        // Edge to edge immersive displays
        enableEdgeToEdge()

        setContent {
            MyApplicationTheme {
                var currentTabRoute by remember { mutableStateOf("dashboard") }

                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    bottomBar = {
                        NavigationBar(
                            containerColor = Color(0xFF121212),
                            contentColor = Color.White,
                            tonalElevation = 8.dp,
                            windowInsets = WindowInsets.navigationBars,
                            modifier = Modifier.testTag("main_bottom_nav_bar")
                        ) {
                            NavigationBarItem(
                                selected = currentTabRoute == "dashboard",
                                onClick = { currentTabRoute = "dashboard" },
                                label = { Text("Home", fontSize = 10.sp, fontWeight = FontWeight.Bold) },
                                icon = { Icon(Icons.Default.Home, contentDescription = "Home") },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = Color(0xFF00F2FF),
                                    selectedTextColor = Color(0xFF00F2FF),
                                    indicatorColor = Color(0xFF303030),
                                    unselectedIconColor = Color(0x80FFFFFF),
                                    unselectedTextColor = Color(0x80FFFFFF)
                                ),
                                modifier = Modifier.testTag("nav_home_tab")
                            )

                            NavigationBarItem(
                                selected = currentTabRoute == "games",
                                onClick = { currentTabRoute = "games" },
                                label = { Text("Games", fontSize = 10.sp, fontWeight = FontWeight.Bold) },
                                icon = { Icon(Icons.Default.SportsEsports, contentDescription = "Games") },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = Color(0xFF00F2FF),
                                    selectedTextColor = Color(0xFF00F2FF),
                                    indicatorColor = Color(0xFF303030),
                                    unselectedIconColor = Color(0x80FFFFFF),
                                    unselectedTextColor = Color(0x80FFFFFF)
                                ),
                                modifier = Modifier.testTag("nav_games_tab")
                            )

                            NavigationBarItem(
                                selected = currentTabRoute == "profiles",
                                onClick = { currentTabRoute = "profiles" },
                                label = { Text("Profiles", fontSize = 10.sp, fontWeight = FontWeight.Bold) },
                                icon = { Icon(Icons.Default.Speed, contentDescription = "Profiles") },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = Color(0xFF00F2FF),
                                    selectedTextColor = Color(0xFF00F2FF),
                                    indicatorColor = Color(0xFF303030),
                                    unselectedIconColor = Color(0x80FFFFFF),
                                    unselectedTextColor = Color(0x80FFFFFF)
                                ),
                                modifier = Modifier.testTag("nav_profiles_tab")
                            )

                            NavigationBarItem(
                                selected = currentTabRoute == "tools",
                                onClick = { currentTabRoute = "tools" },
                                label = { Text("Tools", fontSize = 10.sp, fontWeight = FontWeight.Bold) },
                                icon = { Icon(Icons.Default.Build, contentDescription = "Tools") },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = Color(0xFF00F2FF),
                                    selectedTextColor = Color(0xFF00F2FF),
                                    indicatorColor = Color(0xFF303030),
                                    unselectedIconColor = Color(0x80FFFFFF),
                                    unselectedTextColor = Color(0x80FFFFFF)
                                ),
                                modifier = Modifier.testTag("nav_tools_tab")
                            )

                            NavigationBarItem(
                                selected = currentTabRoute == "shizuku",
                                onClick = { currentTabRoute = "shizuku" },
                                label = { Text("Shizuku", fontSize = 10.sp, fontWeight = FontWeight.Bold) },
                                icon = { Icon(Icons.Default.Shield, contentDescription = "Shizuku") },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = Color(0xFF00F2FF),
                                    selectedTextColor = Color(0xFF00F2FF),
                                    indicatorColor = Color(0xFF303030),
                                    unselectedIconColor = Color(0x80FFFFFF),
                                    unselectedTextColor = Color(0x80FFFFFF)
                                ),
                                modifier = Modifier.testTag("nav_shizuku_tab")
                            )
                        }
                    },
                    topBar = {
                        Column {
                            // Immersive Status bar padding safe guard
                            Spacer(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .windowInsetsTopHeight(WindowInsets.statusBars)
                                    .background(Color.Black)
                            )
                            
                            // Immersive dynamic header bar
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(Color.Black)
                                    .padding(horizontal = 16.dp, vertical = 10.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = "BOOSTIX",
                                        color = Color.White,
                                        fontWeight = FontWeight.Black,
                                        fontSize = 16.sp,
                                        letterSpacing = 1.sp
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "v1.0",
                                        color = Color(0xFF00F2FF),
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 11.sp
                                    )
                                }

                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    IconButton(
                                        onClick = { currentTabRoute = "monitor" },
                                        modifier = Modifier.size(24.dp)
                                    ) {
                                        Icon(Icons.Default.QueryStats, contentDescription = "Query Monitors", tint = Color.LightGray)
                                    }
                                    Spacer(modifier = Modifier.width(12.dp))
                                    IconButton(
                                        onClick = { currentTabRoute = "device_info" },
                                        modifier = Modifier.size(24.dp)
                                    ) {
                                        Icon(Icons.Default.Info, contentDescription = "Device Specifications", tint = Color.LightGray)
                                    }
                                    Spacer(modifier = Modifier.width(12.dp))
                                    IconButton(
                                        onClick = { currentTabRoute = "settings" },
                                        modifier = Modifier.size(24.dp)
                                    ) {
                                        Icon(Icons.Default.Settings, contentDescription = "Preferences Control Deck", tint = Color.LightGray)
                                    }
                                }
                            }
                        }
                    }
                ) { innerPadding ->
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                            .background(Color.Black)
                    ) {
                        AnimatedContent(
                            targetState = currentTabRoute,
                            transitionSpec = {
                                fadeIn() togetherWith fadeOut()
                            },
                            label = "screen_navigation_content"
                        ) { targetRoute ->
                            when (targetRoute) {
                                "dashboard" -> DashboardScreen(
                                    viewModel = viewModel,
                                    onNavigateToGames = { currentTabRoute = "games" },
                                    onNavigateToShizuku = { currentTabRoute = "shizuku" },
                                    onNavigateToMonitor = { currentTabRoute = "monitor" }
                                )
                                "games" -> GamesScreen(viewModel = viewModel)
                                "profiles" -> ProfilesScreen(viewModel = viewModel)
                                "tools" -> ToolsScreen(viewModel = viewModel)
                                "shizuku" -> ShizukuScreen(viewModel = viewModel)
                                "monitor" -> MonitorScreen(viewModel = viewModel)
                                "device_info" -> DeviceInfoScreen(viewModel = viewModel)
                                "settings" -> SettingsScreen(viewModel = viewModel)
                            }
                        }
                    }
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        viewModel.updateShizukuStatus()
        viewModel.checkOverlayStatus()
    }
}
