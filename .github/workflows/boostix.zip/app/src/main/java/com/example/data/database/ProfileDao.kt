package com.example.data.database

import androidx.room.*
import com.example.data.model.PerformanceProfile
import kotlinx.coroutines.flow.Flow

@Dao
interface ProfileDao {
    @Query("SELECT * FROM performance_profiles")
    fun getAllProfiles(): Flow<List<PerformanceProfile>>

    @Query("SELECT * FROM performance_profiles WHERE id = :id LIMIT 1")
    suspend fun getProfileById(id: String): PerformanceProfile?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProfiles(profiles: List<PerformanceProfile>)

    @Update
    suspend fun updateProfile(profile: PerformanceProfile)
}
