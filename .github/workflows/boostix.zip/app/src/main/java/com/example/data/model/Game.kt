package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "games")
data class Game(
    @PrimaryKey val packageName: String,
    val title: String,
    val isFavorite: Boolean = false,
    val lastPlayed: Long = 0L,
    val wasAddedByUser: Boolean = false,
    val selectedProfileId: String? = null, // "battery", "balanced", "performance", "extreme"
    val customBrightness: Float = -1f,      // -1f means use system/default
    val customRefreshRate: Int = -1,        // -1 means system/default
    val autoDnd: Boolean = true,
    val autoLockRotation: Boolean = false,
    val autoOptimize: Boolean = true
)
