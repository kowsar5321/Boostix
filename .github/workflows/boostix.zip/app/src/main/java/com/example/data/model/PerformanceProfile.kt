package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "performance_profiles")
data class PerformanceProfile(
    @PrimaryKey val id: String, // "battery", "balanced", "performance", "extreme"
    val name: String,
    val description: String,
    val dndEnabled: Boolean,
    val brightnessLevel: Float, // -1f = auto, 0.0f - 1.0f = hardcoded level
    val autoLockRotation: Boolean,
    val customRefreshRate: Int, // -1 = default, 60, 90, 120
    val autoOptimize: Boolean
) {
    companion object {
        fun getDefaults(): List<PerformanceProfile> {
            return listOf(
                PerformanceProfile(
                    id = "battery",
                    name = "Battery Saver",
                    description = "Nonsensical background power cut, brightness capped at 40%, and standard refresh rate to conserve battery lifetime.",
                    dndEnabled = false,
                    brightnessLevel = 0.4f,
                    autoLockRotation = false,
                    customRefreshRate = 60,
                    autoOptimize = false
                ),
                PerformanceProfile(
                    id = "balanced",
                    name = "Balanced Mode",
                    description = "Optimal power and frame rate, auto brightness, standard DND, ready for smooth everyday sessions.",
                    dndEnabled = false,
                    brightnessLevel = -1f,
                    autoLockRotation = false,
                    customRefreshRate = -1,
                    autoOptimize = true
                ),
                PerformanceProfile(
                    id = "performance",
                    name = "Performance Mode",
                    description = "Aggressive background app standby, automatic DND, locked rotation, dynamic high refresh rate, and 80% custom brightness.",
                    dndEnabled = true,
                    brightnessLevel = 0.8f,
                    autoLockRotation = true,
                    customRefreshRate = 90,
                    autoOptimize = true
                ),
                PerformanceProfile(
                    id = "extreme",
                    name = "Extreme Gaming Mode",
                    description = "Absolute maximum system speed, deep process clearance, force-stop non-critical apps, strict DND, 100% full brightness, maximum available refresh rate.",
                    dndEnabled = true,
                    brightnessLevel = 1.0f,
                    autoLockRotation = true,
                    customRefreshRate = 120,
                    autoOptimize = true
                )
            )
        }
    }
}
