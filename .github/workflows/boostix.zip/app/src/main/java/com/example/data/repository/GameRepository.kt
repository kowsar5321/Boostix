package com.example.data.repository

import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.util.Base64
import android.util.Log
import com.example.data.database.AppDatabase
import com.example.data.model.Game
import com.example.data.model.LogEntry
import com.example.data.model.PerformanceProfile
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream

class GameRepository(private val context: Context) {
    private val db = AppDatabase.getDatabase(context)
    private val gameDao = db.gameDao()
    private val logDao = db.logDao()
    private val profileDao = db.profileDao()

    val allGames: Flow<List<Game>> = gameDao.getAllGames()
    val favoriteGames: Flow<List<Game>> = gameDao.getFavoriteGames()
    val recentlyPlayedGames: Flow<List<Game>> = gameDao.getRecentlyPlayedGames()
    val allLogs: Flow<List<LogEntry>> = logDao.getAllLogs()
    val allProfiles: Flow<List<PerformanceProfile>> = profileDao.getAllProfiles()

    /**
     * Initializes configuration of default performance profiles if they have not been added yet,
     * and performs the installed application scan for games.
     */
    suspend fun initializeDatabase() = withContext(Dispatchers.IO) {
        try {
            // Seed default profiles if none exist
            val existingProfiles = allProfiles.first()
            if (existingProfiles.isEmpty()) {
                profileDao.insertProfiles(PerformanceProfile.getDefaults())
                logDao.insertLog(LogEntry(type = "SHIZUKU", message = "System configurations initialized. Seeding default optimization profiles."))
            }

            // Seed sample games if database is empty so sandbox/emulators show amazing designs
            val existingGames = allGames.first()
            if (existingGames.isEmpty()) {
                scanAndPopulateGames()
            }
        } catch (e: Exception) {
            Log.e("GameRepository", "Error during DB initialization: ${e.message}")
        }
    }

    /**
     * Scans installed applications for actual Games, or falls back to standard popular gaming items if empty.
     */
    suspend fun scanAndPopulateGames() = withContext(Dispatchers.IO) {
        val pm = context.packageManager
        val installedApps = pm.getInstalledApplications(PackageManager.GET_META_DATA)
        val detectedGames = mutableListOf<Game>()

        for (app in installedApps) {
            val isGame = (app.category == ApplicationInfo.CATEGORY_GAME) || 
                         ((app.flags and ApplicationInfo.FLAG_IS_GAME) != 0) ||
                         app.packageName.contains("game", ignoreCase = true)
                         
            if (isGame && app.packageName != context.packageName) {
                detectedGames.add(
                    Game(
                        packageName = app.packageName,
                        title = app.loadLabel(pm).toString(),
                        isFavorite = false,
                        lastPlayed = 0L
                    )
                )
            }
        }

        // Seeding sandbox/playground items if no real games are detected in this environment
        if (detectedGames.isEmpty()) {
            detectedGames.addAll(
                listOf(
                    Game("com.tencent.ig", "PUBG MOBILE", isFavorite = true, lastPlayed = System.currentTimeMillis() - 3600000, selectedProfileId = "extreme"),
                    Game("com.miHoYo.GenshinImpact", "Genshin Impact", isFavorite = true, lastPlayed = System.currentTimeMillis() - 86400000, selectedProfileId = "performance"),
                    Game("com.mojang.minecraftpe", "Minecraft", isFavorite = false, lastPlayed = 0L, selectedProfileId = "balanced"),
                    Game("com.dts.freefireth", "Free Fire", isFavorite = false, lastPlayed = System.currentTimeMillis() - 172800000, selectedProfileId = "extreme"),
                    Game("com.supercell.brawlstars", "Brawl Stars", isFavorite = false, lastPlayed = 0, selectedProfileId = "battery")
                )
            )
            logDao.insertLog(LogEntry(type = "LAUNCH", message = "Game scan finished. Simulated popular game spaces configured for visual playground."))
        } else {
            logDao.insertLog(LogEntry(type = "LAUNCH", message = "Auto-scanned device storage. Successfully identified ${detectedGames.size} game space components."))
        }

        gameDao.insertGames(detectedGames)
    }

    /**
     * Adds an arbitrary user-installed application (e.g. Chrome, YouTube) manually into the launcher app list.
     */
    suspend fun addAppAsGame(packageName: String, label: String) = withContext(Dispatchers.IO) {
        val game = Game(
            packageName = packageName,
            title = label,
            wasAddedByUser = true
        )
        gameDao.insertGame(game)
        logDao.insertLog(LogEntry(type = "LAUNCH", message = "Manually configured launcher space for '$label' ($packageName)."))
    }

    /**
     * Updates game parameters like Favorite state or customized profile overrides.
     */
    suspend fun updateGame(game: Game) = withContext(Dispatchers.IO) {
        gameDao.updateGame(game)
    }

    /**
     * Launches a game, updating its lastPlayed status, and adding a log entry.
     */
    suspend fun launchGame(packageName: String, label: String) = withContext(Dispatchers.IO) {
        val game = gameDao.getGameByPackage(packageName)
        if (game != null) {
            gameDao.updateGame(game.copy(lastPlayed = System.currentTimeMillis()))
        }
        logDao.insertLog(LogEntry(
            type = "LAUNCH", 
            message = "Launched target session for '$label' ($packageName) under applied constraints."
        ))
    }

    // Logging helpers
    suspend fun addLog(type: String, message: String) = withContext(Dispatchers.IO) {
        logDao.insertLog(LogEntry(type = type, message = message))
    }

    suspend fun clearLogs() = withContext(Dispatchers.IO) {
        logDao.clearLogs()
    }

    // Profile update
    suspend fun updateProfile(profile: PerformanceProfile) = withContext(Dispatchers.IO) {
        profileDao.updateProfile(profile)
        logDao.insertLog(LogEntry(
            type = "PROFILE_CHANGE", 
            message = "Performance Profile '${profile.name}' parameters modified."
        ))
    }

    /**
     * Helper to load the app icon as a Drawable, or supply a sleek fallback if it fails.
     */
    fun getAppIcon(packageName: String): Drawable? {
        return try {
            context.packageManager.getApplicationIcon(packageName)
        } catch (e: Exception) {
            null
        }
    }
}
