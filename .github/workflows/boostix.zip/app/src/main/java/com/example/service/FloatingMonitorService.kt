package com.example.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DragHandle
import androidx.compose.material.icons.filled.Minimize
import androidx.compose.material.icons.filled.OpenInFull
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.ViewModelStore
import androidx.lifecycle.ViewModelStoreOwner
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.lifecycle.setViewTreeViewModelStoreOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner
import com.example.util.SystemMonitor
import kotlinx.coroutines.*
import kotlin.math.roundToInt
import kotlin.random.Random

class FloatingMonitorService : Service() {

    private lateinit var windowManager: WindowManager
    private var overlayLayout: FrameLayout? = null
    private var systemMonitor: SystemMonitor? = null
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())

    companion object {
        private const val CHANNEL_ID = "boostix_overlay_service_channel"
        private const val NOTIFICATION_ID = 263
        var isServiceRunning = false
    }

    override fun onCreate() {
        super.onCreate()
        isServiceRunning = true
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        systemMonitor = SystemMonitor(this).apply { startMonitoring() }

        createNotificationChannel()
        startForeground(NOTIFICATION_ID, getNotification())
        
        showFloatingOverlay()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        return START_NOT_STICKY
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Boostix Overlay Service",
                NotificationManager.IMPORTANCE_LOW
            )
            val manager = getSystemService(NotificationManager::class.java)
            manager?.createNotificationChannel(channel)
        }
    }

    private fun getNotification(): Notification {
        val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, CHANNEL_ID)
        } else {
            Notification.Builder(this)
        }

        return builder
            .setContentTitle("Boostix Overlay Active")
            .setContentText("Real-time telemetry and overlay analytics running in background.")
            .setSmallIcon(android.R.drawable.sym_def_app_icon)
            .setOngoing(true)
            .build()
    }

    private fun showFloatingOverlay() {
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            } else {
                WindowManager.LayoutParams.TYPE_PHONE
            },
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 100
            y = 200
        }

        overlayLayout = FrameLayout(this)
        val composeView = ComposeView(this).apply {
            setContent {
                var isMinimized by remember { mutableStateOf(false) }
                var transparency by remember { mutableFloatStateOf(0.9f) }
                var overlayWidth by remember { mutableStateOf(240.dp) }

                // Live values collected from SystemMonitor
                val ramRatio by systemMonitor!!.ramUsage.collectAsState()
                val cpuRatio by systemMonitor!!.cpuUsage.collectAsState()
                var simulatedFps by remember { mutableIntStateOf(60) }
                val devTemp by systemMonitor!!.deviceTemp.collectAsState()
                val netSpeed by systemMonitor!!.networkSpeed.collectAsState()

                // Minor local jitter for FPS estimation in overlay
                LaunchedEffect(Unit) {
                    while (isActive) {
                        delay(1000)
                        simulatedFps = 58 + Random.nextInt(5)
                    }
                }

                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = Color(0xFF07070F).copy(alpha = transparency),
                    border = BorderStroke(1.dp, Color(0xFF00FFCC).copy(alpha = 0.5f)),
                    modifier = Modifier
                        .width(if (isMinimized) 56.dp else overlayWidth)
                        .padding(4.dp)
                ) {
                    if (isMinimized) {
                        IconButton(
                            onClick = { isMinimized = false },
                            modifier = Modifier.size(48.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.OpenInFull,
                                contentDescription = "Expand",
                                tint = Color(0xFF00FFCC)
                            )
                        }
                    } else {
                        Column(
                            modifier = Modifier
                                .padding(8.dp)
                                .animateContentSize()
                        ) {
                            // Header Row
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.pointerInput(Unit) {
                                        detectDragGestures { change, dragAmount ->
                                            change.consume()
                                            params.x = (params.x + dragAmount.x).roundToInt()
                                            params.y = (params.y + dragAmount.y).roundToInt()
                                            windowManager.updateViewLayout(overlayLayout, params)
                                        }
                                    }
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.DragHandle,
                                        contentDescription = "Drag",
                                        tint = Color.Gray,
                                        modifier = Modifier.size(20.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = "BOOSTIX",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFF00FFCC)
                                    )
                                }

                                Row {
                                    IconButton(
                                        onClick = { isMinimized = true },
                                        modifier = Modifier.size(20.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Minimize,
                                            contentDescription = "Minimize",
                                            tint = Color.White,
                                            modifier = Modifier.size(14.dp)
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(6.dp))
                                    IconButton(
                                        onClick = { stopSelf() },
                                        modifier = Modifier.size(20.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Close,
                                            contentDescription = "Close",
                                            tint = Color.Red,
                                            modifier = Modifier.size(14.dp)
                                        )
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(6.dp))

                            // Telemetry Stats
                            TelemetryItem(label = "FPS", value = "$simulatedFps", color = Color(0xFF00FF66))
                            TelemetryItem(label = "CPU", value = "${(cpuRatio * 100).toInt()}%", color = Color(0xFF33CCFF))
                            TelemetryItem(label = "RAM", value = "${(ramRatio * 100).toInt()}%", color = Color(0xFFFFCC00))
                            TelemetryItem(label = "TEMP", value = String.format("%.1f°C", devTemp), color = Color(0xFFFF3366))
                            TelemetryItem(label = "NET", value = String.format("%.2f Mbps", netSpeed), color = Color(0xFFCC33FF))

                            Spacer(modifier = Modifier.height(8.dp))

                            // Transparency slider
                            Text("Opacity", fontSize = 9.sp, color = Color.Gray)
                            Slider(
                                value = transparency,
                                onValueChange = { transparency = it.coerceIn(0.3f, 0.95f) },
                                modifier = Modifier.height(18.dp).fillMaxWidth()
                            )

                            // Size toggler
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("Width", fontSize = 9.sp, color = Color.Gray)
                                Row {
                                    TextButton(
                                        onClick = { overlayWidth = 180.dp },
                                        contentPadding = PaddingValues(2.dp),
                                        modifier = Modifier.height(20.dp)
                                    ) {
                                        Text("S", fontSize = 9.sp, color = if (overlayWidth == 180.dp) Color(0xFF00FFCC) else Color.White)
                                    }
                                    TextButton(
                                        onClick = { overlayWidth = 240.dp },
                                        contentPadding = PaddingValues(2.dp),
                                        modifier = Modifier.height(20.dp)
                                    ) {
                                        Text("M", fontSize = 9.sp, color = if (overlayWidth == 240.dp) Color(0xFF00FFCC) else Color.White)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Set proper view tree lifecycles so Compose survives in background Service
        val lifecycleOwner = MyLifecycleOwner()
        lifecycleOwner.performRestore(null)
        lifecycleOwner.handleLifecycleEvent(Lifecycle.Event.ON_CREATE)
        lifecycleOwner.handleLifecycleEvent(Lifecycle.Event.ON_START)
        lifecycleOwner.handleLifecycleEvent(Lifecycle.Event.ON_RESUME)

        composeView.setViewTreeLifecycleOwner(lifecycleOwner)
        composeView.setViewTreeViewModelStoreOwner(object : ViewModelStoreOwner {
            override val viewModelStore = ViewModelStore()
        })
        composeView.setViewTreeSavedStateRegistryOwner(lifecycleOwner)

        overlayLayout?.addView(composeView)
        windowManager.addView(overlayLayout, params)
    }

    override fun onDestroy() {
        super.onDestroy()
        isServiceRunning = false
        systemMonitor?.stopMonitoring()
        scope.cancel()
        overlayLayout?.let {
            windowManager.removeView(it)
        }
    }

    @Composable
    private fun TelemetryItem(label: String, value: String, color: Color) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 1.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(label, fontSize = 11.sp, color = Color.LightGray)
            Text(value, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = color)
        }
    }

    // A helper standalone lifecycle owner to back Compose inside the Service
    private class MyLifecycleOwner : androidx.savedstate.SavedStateRegistryOwner {
        private val registry = androidx.lifecycle.LifecycleRegistry(this)
        private val savedStateRegistryController = androidx.savedstate.SavedStateRegistryController.create(this)

        fun handleLifecycleEvent(event: Lifecycle.Event) {
            registry.handleLifecycleEvent(event)
        }

        override val lifecycle: Lifecycle = registry
        override val savedStateRegistry = savedStateRegistryController.savedStateRegistry

        fun performRestore(savedState: android.os.Bundle?) {
            savedStateRegistryController.performRestore(savedState)
        }
    }
}
