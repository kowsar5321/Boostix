package com.example.ui.screens

import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Game
import com.example.ui.viewmodel.BoostixViewModel
import kotlinx.coroutines.delay

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DashboardScreen(
    viewModel: BoostixViewModel,
    onNavigateToGames: () -> Unit,
    onNavigateToShizuku: () -> Unit,
    onNavigateToMonitor: () -> Unit
) {
    val context = LocalContext.current
    val scrollState = rememberScrollState()

    // Live variables
    val totalGames by viewModel.allGames.collectAsState()
    val recentGames by viewModel.recentlyPlayedGames.collectAsState()
    val isOptimizing by viewModel.isOptimizing.collectAsState()
    val statusMessage by viewModel.statusMessage.collectAsState()
    val activeProfileId by viewModel.activeProfileId.collectAsState()

    val ramRatio by viewModel.ramUsage.collectAsState()
    val cpuRatio by viewModel.cpuUsage.collectAsState()
    val batLevel by viewModel.batteryLevel.collectAsState()
    val devTemp by viewModel.deviceTemp.collectAsState()
    val shizukuActive by viewModel.shizukuRunning.collectAsState()

    // Quick boost circular animation rotation
    val transition = rememberInfiniteTransition(label = "boost_rotation")
    val rotationAngle by transition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(2000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "rotation"
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(scrollState)
                .padding(16.dp)
                .padding(bottom = 80.dp) // padding safe bottom
        ) {
            // Elegant Header
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "BOOSTIX",
                        fontSize = 24.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = Color.White,
                        letterSpacing = 1.sp,
                        style = MaterialTheme.typography.headlineMedium
                    )
                    Text(
                        text = "Optimize Smart. Play Better.",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium,
                        color = Color(0xFF939094)
                    )
                }

                // Profile Badge
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(30.dp))
                        .background(Color(0xFF1C1B1F))
                        .border(1.dp, Color(0x33FFFFFF), RoundedCornerShape(30.dp))
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .clip(CircleShape)
                                .background(
                                    when (activeProfileId) {
                                        "extreme" -> Color(0xFFFF4B4B)
                                        "performance" -> Color(0xFFFF8A00)
                                        "battery" -> Color(0xFF34D399)
                                        else -> Color(0xFF00F2FF)
                                    }
                                )
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = activeProfileId.uppercase(),
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Real-time circular central Optimizer Ring Button
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1C1B1F)),
                shape = RoundedCornerShape(24.dp),
                border = BorderStroke(1.dp, Color(0x0FFFFFFF)),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 10.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier
                            .size(170.dp)
                            .clickable(enabled = !isOptimizing) {
                                viewModel.runQuickBoost()
                            }
                    ) {
                        // Glowing outer circle rotation if optimizing
                        Box(
                            modifier = Modifier
                                .size(160.dp)
                                .border(
                                    border = BorderStroke(
                                        width = 3.dp,
                                        brush = Brush.sweepGradient(
                                            colors = listOf(
                                                Color(0xFF00F2FF),
                                                Color(0xFF2C2B2F),
                                                Color(0xFF00F2FF),
                                                Color(0xFF2C2B2F)
                                            )
                                        )
                                    ),
                                    shape = CircleShape
                                )
                                .rotate(if (isOptimizing) rotationAngle else 0f)
                        )

                        // Central core booster container
                        Box(
                            contentAlignment = Alignment.Center,
                            modifier = Modifier
                                .size(136.dp)
                                .clip(CircleShape)
                                .background(
                                    Brush.radialGradient(
                                        colors = listOf(
                                            Color(0xFF2C2B2F),
                                            Color(0xFF121212)
                                        )
                                    )
                                )
                        ) {
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.Center
                            ) {
                                Icon(
                                    imageVector = if (isOptimizing) Icons.Default.Autorenew else Icons.Default.Bolt,
                                    contentDescription = "Boost Icon",
                                    tint = if (isOptimizing) Color(0xFFE0A0FF) else Color(0xFF00F2FF),
                                    modifier = Modifier
                                        .size(46.dp)
                                        .rotate(if (isOptimizing) rotationAngle else 0f)
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = if (isOptimizing) "TUNING..." else "QUICK BOOST",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White,
                                    letterSpacing = 1.sp
                                )
                                Text(
                                    text = if (isOptimizing) "Optimising..." else "Ready Engine",
                                    fontSize = 9.sp,
                                    color = Color(0xFF939094)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Dynamic message logs panel
                    Text(
                        text = statusMessage,
                        fontSize = 12.sp,
                        color = if (isOptimizing) Color(0xFF00F2FF) else Color(0xFFE3E2E6),
                        textAlign = TextAlign.Center,
                        fontWeight = FontWeight.Medium,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 8.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Quick Hardware Stats Row
            Row(
                modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                HardwareGridCard(
                    title = "RAM",
                    value = "${(ramRatio * 100).toInt()}%",
                    icon = Icons.Default.Memory,
                    progress = ramRatio,
                    color = Color(0xFF00F2FF),
                    modifier = Modifier.weight(1f).onClick { onNavigateToMonitor() }
                )
                Spacer(modifier = Modifier.width(10.dp))
                HardwareGridCard(
                    title = "CPU",
                    value = "${(cpuRatio * 100).toInt()}%",
                    icon = Icons.Default.DeveloperBoard,
                    progress = cpuRatio,
                    color = Color(0xFFE0A0FF),
                    modifier = Modifier.weight(1f).onClick { onNavigateToMonitor() }
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                HardwareGridCard(
                    title = "BATTERY",
                    value = "$batLevel%",
                    icon = Icons.Default.BatteryChargingFull,
                    progress = batLevel / 100f,
                    color = Color(0xFF34D399),
                    modifier = Modifier.weight(1f)
                )
                Spacer(modifier = Modifier.width(10.dp))
                HardwareGridCard(
                    title = "TEMP",
                    value = String.format("%.1f°C", devTemp),
                    icon = Icons.Default.Thermostat,
                    progress = (devTemp / 75f).coerceIn(0f, 1f),
                    color = Color(0xFFFF8A00),
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Quick Shizuku Status Banner
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1C1B1F)),
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, if (shizukuActive) Color(0xFF34D399).copy(alpha = 0.3f) else Color(0xFFFF4B4B).copy(alpha = 0.3f)),
                onClick = onNavigateToShizuku,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 6.dp)
                    .testTag("shizuku_status_dashboard")
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = if (shizukuActive) Icons.Default.VerifiedUser else Icons.Default.GppBad,
                            contentDescription = "Shizuku",
                            tint = if (shizukuActive) Color(0xFF34D399) else Color(0xFFFF4B4B),
                            modifier = Modifier.size(32.dp)
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "Shizuku Service Status",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = Color.White
                            )
                            Text(
                                text = if (shizukuActive) "Running securely with core integration" else "Disconnected. Setup instructions available.",
                                fontSize = 11.sp,
                                color = Color(0xFF939094)
                            )
                        }
                    }

                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                        contentDescription = "Go",
                        tint = Color.Gray,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Recent Played Games list
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "RECENTLY PLAYED",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White,
                    letterSpacing = 1.sp
                )

                Text(
                    text = "See All (${totalGames.size})",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = Color(0xFF00F2FF),
                    modifier = Modifier.clickable { onNavigateToGames() }
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            if (recentGames.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(80.dp)
                        .border(1.dp, Color(0x1AFFFFFF), RoundedCornerShape(12.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "No recently played games listed. Start gaming!",
                        color = Color.Gray,
                        fontSize = 11.sp
                    )
                }
            } else {
                LazyRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(recentGames) { game ->
                        RecentGameCard(game = game) {
                            viewModel.launchGame(
                                packageName = game.packageName,
                                title = game.title,
                                onLaunchRequired = { startIntent ->
                                    context.startActivity(startIntent)
                                },
                                onFail = { errorMsg ->
                                    Toast.makeText(context, errorMsg, Toast.LENGTH_SHORT).show()
                                }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun HardwareGridCard(
    title: String,
    value: String,
    icon: ImageVector,
    progress: Float,
    color: Color,
    modifier: Modifier = Modifier
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color(0xFF1C1B1F)),
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(1.dp, Color(0x0FFFFFFF)),
        modifier = modifier
    ) {
        Column(
            modifier = Modifier.padding(14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = title,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF939094)
                )
                Icon(
                    imageVector = icon,
                    contentDescription = title,
                    tint = color,
                    modifier = Modifier.size(16.dp)
                )
            }
            Spacer(modifier = Modifier.height(10.dp))
            Text(
                text = value,
                fontSize = 20.sp,
                fontWeight = FontWeight.Black,
                color = Color.White
            )
            Spacer(modifier = Modifier.height(6.dp))
            LinearProgressIndicator(
                progress = { progress },
                modifier = Modifier.fillMaxWidth().height(3.dp),
                color = color,
                trackColor = color.copy(alpha = 0.15f)
            )
        }
    }
}

@Composable
fun RecentGameCard(
    game: Game,
    onClick: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color(0xFF1C1B1F)),
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(1.dp, Color(0x0FFFFFFF)),
        modifier = Modifier
            .width(135.dp)
            .clickable { onClick() }
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(10.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Simulated game icon avatar with custom backgrounds matching title
            Box(
                modifier = Modifier
                    .size(56.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(
                                Color(0xFF00F2FF).copy(alpha = 0.2f),
                                Color(0xFFE0A0FF).copy(alpha = 0.2f)
                            )
                        )
                    )
                    .border(1.dp, Color(0xFF00F2FF).copy(alpha = 0.3f), RoundedCornerShape(12.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.SportsEsports,
                    contentDescription = "Game Icon Logo",
                    tint = Color(0xFF00F2FF),
                    modifier = Modifier.size(28.dp)
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = game.title,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White,
                maxLines = 1,
                textAlign = TextAlign.Center
            )

            Text(
                text = game.selectedProfileId?.uppercase() ?: "BALANCED",
                fontSize = 8.sp,
                color = Color(0xFF00F2FF),
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier.padding(top = 2.dp)
            )
        }
    }
}

// Custom click Modifier for grid elements
@OptIn(ExperimentalMaterial3Api::class)
fun Modifier.onClick(block: () -> Unit): Modifier = this.clickable(onClick = block)
