package com.example.ui.screens

import android.os.Build
import android.os.Environment
import android.os.StatFs
import android.util.DisplayMetrics
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.viewmodel.BoostixViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DeviceInfoScreen(viewModel: BoostixViewModel) {
    val context = LocalContext.current
    val scrollState = rememberScrollState()

    // Real specs compiled via android.os.Build and System files
    val manufacturer = remember { Build.MANUFACTURER.uppercase() }
    val model = remember { Build.MODEL }
    val brand = remember { Build.BRAND.uppercase() }
    val device = remember { Build.DEVICE }
    val androidVersion = remember { Build.VERSION.RELEASE }
    val sdkVersion = remember { Build.VERSION.SDK_INT }
    val hardware = remember { Build.HARDWARE }
    val product = remember { Build.PRODUCT }
    val bootloader = remember { Build.BOOTLOADER }
    
    // Kernel Version
    val kernelVersion = remember { System.getProperty("os.version") ?: "Unable to parse kernel" }

    // Screen specs
    val metrics = context.resources.displayMetrics
    val resolutionX = metrics.widthPixels
    val resolutionY = metrics.heightPixels
    val densityDpi = metrics.densityDpi
    val refreshRate = remember {
        val wm = context.getSystemService(android.content.Context.WINDOW_SERVICE) as android.view.WindowManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            wm.defaultDisplay?.mode?.refreshRate?.toInt() ?: 60
        } else {
            wm.defaultDisplay?.refreshRate?.toInt() ?: 60
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
            .padding(16.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(scrollState)
                .padding(bottom = 70.dp) // margin navigation tab bar
        ) {
            Text(
                text = "SYSTEM IDENTIFIER",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF00F2FF),
                letterSpacing = 1.5.sp
            )
            Text(
                text = "DEVICE INFORMATION",
                fontSize = 22.sp,
                fontWeight = FontWeight.Black,
                color = Color.White,
                modifier = Modifier.padding(bottom = 12.dp)
            )

            // Section 1: Manufacturer Signature
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1C1B1F)),
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, Color(0x0FFFFFFF)),
                modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp)
            ) {
                Row(
                    modifier = Modifier.padding(16.dp).fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.PhoneAndroid,
                        contentDescription = "Device info",
                        tint = Color(0xFF00F2FF),
                        modifier = Modifier.size(36.dp)
                    )
                    Spacer(modifier = Modifier.width(16.dp))
                    Column {
                        Text(
                            text = "$brand $model",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Black,
                            color = Color.White
                        )
                        Text(
                            text = "Specs mapped via raw kernel Build configuration",
                            fontSize = 11.sp,
                            color = Color(0xFF939094)
                        )
                    }
                }
            }

            // Specs grid details
            SpecRowPair(
                title1 = "Manufacturer", val1 = manufacturer, icon1 = Icons.Default.SettingsSuggest,
                title2 = "Device Name", val2 = device, icon2 = Icons.Default.Badge
            )
            SpecRowPair(
                title1 = "Android version", val1 = "$androidVersion (API $sdkVersion)", icon1 = Icons.Default.Android,
                title2 = "Kernel Release", val2 = kernelVersion, icon2 = Icons.Default.Code
            )
            SpecRowPair(
                title1 = "SOC Hardware", val1 = hardware.uppercase(), icon1 = Icons.Default.DeveloperBoard,
                title2 = "Target Product", val2 = product, icon2 = Icons.Default.Layers
            )
            SpecRowPair(
                title1 = "Resolution Details", val1 = "${resolutionX}x${resolutionY} px", icon1 = Icons.Default.AspectRatio,
                title2 = "Screen Refresh Rate", val2 = "$refreshRate Hz", icon2 = Icons.Default.Refresh
            )
            SpecRowPair(
                title1 = "Bootloader", val1 = bootloaderPosition(bootloader), icon1 = Icons.Default.RestartAlt,
                title2 = "DPI density", val2 = "$densityDpi dpi", icon2 = Icons.Default.GridGoldenratio
            )
        }
    }
}

private fun bootloaderPosition(bl: String): String {
    return if (bl == "unknown") "SECURE" else bl
}

@Composable
fun SpecRowPair(
    title1: String, val1: String, icon1: ImageVector,
    title2: String, val2: String, icon2: ImageVector
) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        SpecGridItem(title = title1, value = val1, icon = icon1, modifier = Modifier.weight(1f))
        SpecGridItem(title = title2, value = val2, icon = icon2, modifier = Modifier.weight(1f))
    }
}

@Composable
fun SpecGridItem(
    title: String,
    value: String,
    icon: ImageVector,
    modifier: Modifier = Modifier
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color(0xFF1C1B1F)),
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(1.dp, Color(0x0FFFFFFF)),
        modifier = modifier
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Icon(imageVector = icon, contentDescription = title, tint = Color(0xFF00F2FF), modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.height(10.dp))
            Text(title, fontSize = 10.sp, color = Color(0xFF939094), fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(2.dp))
            Text(value, fontSize = 12.sp, color = Color.White, fontWeight = FontWeight.Black, maxLines = 2)
        }
    }
}
