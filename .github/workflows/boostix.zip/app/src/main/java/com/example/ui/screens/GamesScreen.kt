package com.example.ui.screens

import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.model.Game
import com.example.ui.viewmodel.BoostixViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GamesScreen(viewModel: BoostixViewModel) {
    val context = LocalContext.current
    val games by viewModel.allGames.collectAsState()
    val favorites by viewModel.favoriteGames.collectAsState()
    val searchQuery by viewModel.searchQuery.collectAsState()
    val installedApps by viewModel.allInstalledApps.collectAsState()

    var showAddAppDialog by remember { mutableStateOf(false) }
    var selectedGameForSettings by remember { mutableStateOf<Game?>(null) }

    // Filtered lists
    val filteredGames = games.filter {
        it.title.contains(searchQuery, ignoreCase = true) || 
        it.packageName.contains(searchQuery, ignoreCase = true)
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
            .padding(16.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(bottom = 70.dp) // margin navigation tab bar
        ) {
            // Header Action
            Row(
                modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "GAMES SPACE",
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Black,
                    color = Color.White
                )

                Row {
                    IconButton(
                        onClick = { viewModel.scanAndRefreshGames() },
                        colors = IconButtonDefaults.iconButtonColors(containerColor = Color(0xFF1C1B1F))
                    ) {
                        Icon(Icons.Default.Refresh, contentDescription = "Scan Storage", tint = Color(0xFF00F2FF))
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = { showAddAppDialog = true },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00F2FF), contentColor = Color.Black),
                        shape = RoundedCornerShape(10.dp),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Icon(Icons.Default.Add, contentDescription = "Add custom App", modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("ADD APP", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Search text bar
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { viewModel.updateSearchQuery(it) },
                placeholder = { Text("Search system or launcher space...", color = Color(0xFF939094), fontSize = 13.sp) },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search", tint = Color(0xFF939094)) },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { viewModel.updateSearchQuery("") }) {
                            Icon(Icons.Default.Clear, contentDescription = "Clear", tint = Color(0xFF939094))
                        }
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("game_search_input"),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Color(0xFF00F2FF),
                    unfocusedBorderColor = Color(0x33FFFFFF),
                    focusedContainerColor = Color(0xFF1C1B1F),
                    unfocusedContainerColor = Color(0xFF1C1B1F),
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White
                ),
                shape = RoundedCornerShape(12.dp),
                singleLine = true
            )

            Spacer(modifier = Modifier.height(14.dp))

            // Dynamic Favorites Row
            if (favorites.isNotEmpty() && searchQuery.isEmpty()) {
                Text(
                    text = "FAVORITE GAMES",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF939094),
                    letterSpacing = 1.5.sp
                )
                Spacer(modifier = Modifier.height(6.dp))
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth().padding(bottom = 14.dp)
                ) {
                    items(favorites) { game ->
                        FavoriteGameCard(game = game, onLaunch = {
                            viewModel.launchGame(
                                packageName = game.packageName,
                                title = game.title,
                                onLaunchRequired = { intent -> context.startActivity(intent) },
                                onFail = { err -> Toast.makeText(context, err, Toast.LENGTH_SHORT).show() }
                            )
                        }, onSettings = { selectedGameForSettings = game })
                    }
                }
            }

            // Games Grid Header
            Text(
                text = "ALL IDENTIFIED GAMES (${filteredGames.size})",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF939094),
                letterSpacing = 1.5.sp,
                modifier = Modifier.padding(vertical = 4.dp)
            )

            if (filteredGames.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .border(1.dp, Color(0x33FFFFFF), RoundedCornerShape(14.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Default.SportsEsports, contentDescription = "Empty", tint = Color(0xFF2C2B2F), modifier = Modifier.size(54.dp))
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("No matching gaming space identified.", color = Color(0xFF939094), fontSize = 13.sp)
                        Text("Click 'ADD APP' to register utilities manually.", color = Color(0x66FFFFFF), fontSize = 11.sp, modifier = Modifier.padding(top = 4.dp))
                    }
                }
            } else {
                LazyVerticalGrid(
                    columns = GridCells.Fixed(2),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    items(filteredGames) { game ->
                        GridGameCard(
                            game = game,
                            onLaunch = {
                                viewModel.launchGame(
                                    packageName = game.packageName,
                                    title = game.title,
                                    onLaunchRequired = { intent -> context.startActivity(intent) },
                                    onFail = { err -> Toast.makeText(context, err, Toast.LENGTH_SHORT).show() }
                                )
                            },
                            onSettings = { selectedGameForSettings = game },
                            onToggleFavorite = { viewModel.toggleGameFavorite(game.packageName) }
                        )
                    }
                }
            }
        }
    }

    // 1. Per-game Customized optimization settings Dialog
    selectedGameForSettings?.let { game ->
        var customBrightness by remember { mutableFloatStateOf(game.customBrightness) }
        var autoDnd by remember { mutableStateOf(game.autoDnd) }
        var autoLockRotation by remember { mutableStateOf(game.autoLockRotation) }
        var autoOptimize by remember { mutableStateOf(game.autoOptimize) }
        var selectedProfile by remember { mutableStateOf(game.selectedProfileId ?: "inherit") }
        var customRefreshIndex by remember { mutableStateOf(when(game.customRefreshRate) { 60 -> 1; 90 -> 2; 120 -> 3; else -> 0 }) }
        
        Dialog(onDismissRequest = { selectedGameForSettings = null }) {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1C1B1F)),
                shape = RoundedCornerShape(20.dp),
                border = BorderStroke(1.dp, Color(0x33FFFFFF)),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                Column(
                    modifier = Modifier
                        .padding(20.dp)
                        .verticalScroll(rememberScrollState())
                ) {
                    Text(
                        text = "PER-GAME PARAMETERS",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF00F2FF),
                        letterSpacing = 1.sp
                    )
                    Text(
                        text = game.title,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Black,
                        color = Color.White,
                        modifier = Modifier.padding(bottom = 12.dp)
                    )

                    HorizontalDivider(color = Color(0x1AFFFFFF), modifier = Modifier.padding(vertical = 4.dp))

                    // Parameter: Profile Bind
                    Text("Target Optimization Profile", fontSize = 11.sp, color = Color(0xFF939094), modifier = Modifier.padding(top = 8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        listOf("inherit", "battery", "balanced", "extreme").forEach { pf ->
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(if (selectedProfile == pf) Color(0xFF303030) else Color(0xFF2C2B2F))
                                    .border(1.dp, if (selectedProfile == pf) Color(0xFF00F2FF) else Color(0x1AFFFFFF), RoundedCornerShape(8.dp))
                                    .clickable { selectedProfile = pf }
                                    .padding(vertical = 6.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(pf.uppercase(), fontSize = 8.sp, fontWeight = FontWeight.Bold, color = if (selectedProfile == pf) Color(0xFF00F2FF) else Color.White)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Parameter: Custom Brightness Slider
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Custom Brightness Override", fontSize = 12.sp, color = Color.White, fontWeight = FontWeight.SemiBold)
                        Text(
                            text = if (customBrightness < 0f) "System Default" else "${(customBrightness * 100).toInt()}%",
                            fontSize = 11.sp,
                            color = Color(0xFF00F2FF)
                        )
                    }
                    Slider(
                        value = if (customBrightness < 0f) 0f else customBrightness,
                        onValueChange = { customBrightness = it },
                        modifier = Modifier.fillMaxWidth(),
                        colors = SliderDefaults.colors(
                            thumbColor = Color(0xFF00F2FF),
                            activeTrackColor = Color(0xFF00F2FF),
                            inactiveTrackColor = Color(0x1AFFFFFF)
                        )
                    )
                    Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                        TextButton(onClick = { customBrightness = -1f }, contentPadding = PaddingValues(0.dp)) {
                            Text("Reset to system auto-brightness", fontSize = 10.sp, color = Color(0xFF939094))
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Parameter: Refresh Rate Row
                    Text("Custom Target Refresh Rate", fontSize = 12.sp, color = Color.White, fontWeight = FontWeight.SemiBold)
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        listOf("Auto", "60 Hz", "90 Hz", "120 Hz").forEachIndexed { index, rate ->
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(if (customRefreshIndex == index) Color(0xFF303030) else Color(0xFF2C2B2F))
                                    .border(1.dp, if (customRefreshIndex == index) Color(0xFF00F2FF) else Color(0x1AFFFFFF), RoundedCornerShape(8.dp))
                                    .clickable { customRefreshIndex = index }
                                    .padding(vertical = 8.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(rate, fontSize = 10.sp, fontWeight = FontWeight.SemiBold, color = if (customRefreshIndex == index) Color(0xFF00F2FF) else Color.White)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Boolean Toggles
                    ToggleItemRow(label = "Auto Do Not Disturb (DND)", value = autoDnd) { autoDnd = it }
                    ToggleItemRow(label = "Auto Lock Screen Rotation", value = autoLockRotation) { autoLockRotation = it }
                    ToggleItemRow(label = "Auto Boost heap before launch", value = autoOptimize) { autoOptimize = it }

                    Spacer(modifier = Modifier.height(20.dp))

                    // Buttons
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End
                    ) {
                        TextButton(onClick = { selectedGameForSettings = null }) {
                            Text("CANCEL", color = Color.Gray)
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Button(
                            onClick = {
                                val rateToSave = when(customRefreshIndex) {
                                    1 -> 60
                                    2 -> 90
                                    3 -> 120
                                    else -> -1
                                }
                                viewModel.saveGameSettings(
                                    game.copy(
                                        selectedProfileId = if (selectedProfile == "inherit") null else selectedProfile,
                                        customBrightness = customBrightness,
                                        customRefreshRate = rateToSave,
                                        autoDnd = autoDnd,
                                        autoLockRotation = autoLockRotation,
                                        autoOptimize = autoOptimize
                                    )
                                )
                                selectedGameForSettings = null
                                Toast.makeText(context, "Configurations saved securely.", Toast.LENGTH_SHORT).show()
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00F2FF), contentColor = Color.Black)
                        ) {
                            Text("SAVE CONFIG", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }

    // 2. Add System apps manual dialogue
    if (showAddAppDialog) {
        var appSearchQuery by remember { mutableStateOf("") }
        val filteredApps = installedApps.filter {
            it.second.contains(appSearchQuery, ignoreCase = true) || 
            it.first.contains(appSearchQuery, ignoreCase = true)
        }

        Dialog(onDismissRequest = { showAddAppDialog = false }) {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1C1B1F)),
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, Color(0x33FFFFFF)),
                modifier = Modifier
                    .fillMaxSize()
                    .padding(vertical = 32.dp)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp)
                ) {
                    Text(
                        text = "REGISTER SYSTEM APPS",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF00F2FF),
                        modifier = Modifier.padding(bottom = 10.dp)
                    )

                    OutlinedTextField(
                        value = appSearchQuery,
                        onValueChange = { appSearchQuery = it },
                        placeholder = { Text("Search installed packages...", color = Color(0xFF939094), fontSize = 12.sp) },
                        modifier = Modifier.fillMaxWidth().height(52.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedBorderColor = Color(0xFF00F2FF),
                            unfocusedBorderColor = Color(0x33FFFFFF),
                            focusedContainerColor = Color(0xFF2C2B2F),
                            unfocusedContainerColor = Color(0xFF2C2B2F)
                        ),
                        singleLine = true
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth().weight(1f)
                    ) {
                        androidx.compose.foundation.lazy.LazyColumn(
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            items(filteredApps) { (packageName, label) ->
                                Card(
                                    colors = CardDefaults.cardColors(containerColor = Color(0xFF2C2B2F)),
                                    border = BorderStroke(1.dp, Color(0x0FFFFFFF)),
                                    onClick = {
                                        viewModel.addInstalledAppAsGame(packageName, label)
                                        showAddAppDialog = false
                                        Toast.makeText(context, "'$label' successfully linked to dashboard.", Toast.LENGTH_SHORT).show()
                                    },
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(
                                        modifier = Modifier.padding(12.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(Icons.Default.Android, contentDescription = "App Icon", tint = Color(0xFF34D399), modifier = Modifier.size(24.dp))
                                        Spacer(modifier = Modifier.width(12.dp))
                                        Column {
                                            Text(label, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                            Text(packageName, color = Color(0xFF939094), fontSize = 9.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                        }
                                    }
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    TextButton(
                        onClick = { showAddAppDialog = false },
                        modifier = Modifier.align(Alignment.End)
                    ) {
                        Text("CLOSE LIST", color = Color(0xFFFF4B4B))
                    }
                }
            }
        }
    }
}

@Composable
fun ToggleItemRow(label: String, value: Boolean, onCheckedChange: (Boolean) -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, fontSize = 11.sp, color = Color.LightGray)
        Switch(
            checked = value,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color(0xFF00F2FF),
                checkedTrackColor = Color(0xFF00F2FF).copy(alpha = 0.3f)
            )
        )
    }
}

@Composable
fun FavoriteGameCard(
    game: Game,
    onLaunch: () -> Unit,
    onSettings: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color(0xFF1C1B1F)),
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(1.dp, Color(0x0FFFFFFF)),
        modifier = Modifier
            .width(180.dp)
            .clickable { onLaunch() }
    ) {
        Row(
            modifier = Modifier.padding(10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color(0xFF00F2FF).copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Default.SportsEsports, contentDescription = "Game Icon", tint = Color(0xFF00F2FF), modifier = Modifier.size(20.dp))
                }
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                    Text(game.title, color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(game.selectedProfileId?.uppercase() ?: "GLOBAL", color = Color(0xFF00F2FF), fontSize = 8.sp, fontWeight = FontWeight.Bold)
                }
            }

            IconButton(
                onClick = onSettings,
                modifier = Modifier.size(24.dp)
            ) {
                Icon(Icons.Default.Settings, contentDescription = "Game Params", tint = Color(0xFF939094), modifier = Modifier.size(16.dp))
            }
        }
    }
}

@Composable
fun GridGameCard(
    game: Game,
    onLaunch: () -> Unit,
    onSettings: () -> Unit,
    onToggleFavorite: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color(0xFF1C1B1F)),
        shape = RoundedCornerShape(14.dp),
        border = BorderStroke(1.dp, Color(0x0FFFFFFF)),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onLaunch() }
            .testTag("game_grid_item_${game.packageName}")
    ) {
        Column(
            modifier = Modifier.padding(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                // Game indicator fallback icon
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color(0xFF2C2B2F))
                        .border(1.dp, Color(0x0FFFFFFF), RoundedCornerShape(8.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Default.SportsEsports, contentDescription = "Game Avatar", tint = Color(0xFF00F2FF), modifier = Modifier.size(24.dp))
                }

                Row {
                    IconButton(
                        onClick = onToggleFavorite,
                        modifier = Modifier.size(24.dp)
                    ) {
                        Icon(
                            imageVector = if (game.isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                            contentDescription = "Fav",
                            tint = if (game.isFavorite) Color(0xFFFF4B4B) else Color(0xFF939094),
                            modifier = Modifier.size(15.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(4.dp))
                    IconButton(
                        onClick = onSettings,
                        modifier = Modifier.size(24.dp).testTag("game_settings_btn_${game.packageName}")
                    ) {
                        Icon(Icons.Default.Tune, contentDescription = "Tune Settings", tint = Color(0xFF00F2FF), modifier = Modifier.size(15.dp))
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = game.title,
                color = Color.White,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )

            Text(
                text = game.packageName,
                color = Color(0xFF939094),
                fontSize = 8.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.padding(top = 1.dp)
            )

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(Color(0xFF2C2B2F))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = game.selectedProfileId?.uppercase() ?: "BALANCED",
                        fontSize = 7.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }

                Icon(
                    imageVector = Icons.Default.PlayArrow,
                    contentDescription = "Launch",
                    tint = Color(0xFF00F2FF),
                    modifier = Modifier.size(14.dp)
                )
            }
        }
    }
}
