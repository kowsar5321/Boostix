package com.example.ui.screens

import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.viewmodel.BoostixViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MonitorScreen(viewModel: BoostixViewModel) {
    val context = LocalContext.current

    // Live monitor states
    val ramRatio by viewModel.ramUsage.collectAsState()
    val ramTotalGb by viewModel.ramTotalGb.collectAsState()
    val ramUsedGb by viewModel.ramUsedGb.collectAsState()

    val cpuRatio by viewModel.cpuUsage.collectAsState()

    val storageRatio by viewModel.storageUsage.collectAsState()
    val storageTotalGb by viewModel.storageTotalGb.collectAsState()
    val storageFreeGb by viewModel.storageFreeGb.collectAsState()

    val batTemp by viewModel.batteryTemp.collectAsState()
    val batLevel by viewModel.batteryLevel.collectAsState()
    val activeCount by viewModel.activeProcessesCount.collectAsState()
    val isOptimizing by viewModel.isOptimizing.collectAsState()

    // Simulation process list
    val processes = remember(activeCount) {
        listOf(
            "com.android.systemui" to "System Interface",
            "com.google.android.gms" to "Google core Services",
            "moe.shizuku.privileged.api" to "Shizuku Shell Engine",
            "com.android.chrome" to "Chrome sandbox processes",
            "com.spotify.music" to "Spotify Audio stream helper",
            "com.discord" to "Discord gaming background sync",
            "com.android.vending" to "Play Store Auto Update daemon",
            "com.whatsapp" to "WhatsApp message polling service",
            "org.telegram.messenger" to "Telegram media cache monitor"
        ).shuffled().take(5)
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
            .padding(16.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(bottom = 70.dp) // margin navigation tab bar
        ) {
            Text(
                text = "TELEMETRY",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF00F2FF),
                letterSpacing = 1.5.sp
            )
            Text(
                text = "REAL-TIME MONITOR",
                fontSize = 22.sp,
                fontWeight = FontWeight.Black,
                color = Color.White,
                modifier = Modifier.padding(bottom = 12.dp)
            )

            // Section 1: Dashboard Circular telemetry card
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1C1B1F)),
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, Color(0x0FFFFFFF)),
                modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp)
            ) {
                Row(
                    modifier = Modifier.padding(16.dp).fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceAround,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    CircularProgressTile(
                        title = "CPU LOAD",
                        ratio = cpuRatio,
                        textValue = "${(cpuRatio * 100).toInt()}%",
                        color = Color(0xFF00F2FF)
                    )
                    CircularProgressTile(
                        title = "RAM USED",
                        ratio = ramRatio,
                        textValue = "${(ramRatio * 100).toInt()}%",
                        color = Color(0xFF34D399)
                    )
                    CircularProgressTile(
                        title = "STORAGE",
                        ratio = storageRatio,
                        textValue = "${(storageRatio * 100).toInt()}%",
                        color = Color(0xFF00F2FF)
                    )
                }
            }

            // Section 2: Storage detailed stat
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1C1B1F)),
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, Color(0x0FFFFFFF)),
                modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Physical Hardware allocation details", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    Spacer(modifier = Modifier.height(8.dp))
                    
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("Random Access Memory (RAM)", fontSize = 11.sp, color = Color(0xFF939094))
                            Text(String.format("Used: %.2f GB / %.1f GB Total", ramUsedGb, ramTotalGb), fontSize = 13.sp, color = Color.White, fontWeight = FontWeight.SemiBold)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text("Disk Flash Storage", fontSize = 11.sp, color = Color(0xFF939094))
                            Text(String.format("Free: %.1f GB / %.1f GB Total", storageFreeGb, storageTotalGb), fontSize = 13.sp, color = Color.White, fontWeight = FontWeight.SemiBold)
                        }
                    }
                }
            }

            // Section 3: Process manager explorer
            Row(
                modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "ACTIVE USER PROCESSES ($activeCount)",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White,
                    letterSpacing = 1.sp
                )

                Button(
                    onClick = { viewModel.runQuickBoost() },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1C1B1F), contentColor = Color(0xFFFF4B4B)),
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                    modifier = Modifier.height(28.dp).border(1.dp, Color(0xFFFF4B4B), RoundedCornerShape(8.dp)),
                    enabled = !isOptimizing
                ) {
                    Icon(Icons.Default.DeleteSweep, contentDescription = "Kill all", modifier = Modifier.size(12.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("TRIM ALL", fontSize = 9.sp, fontWeight = FontWeight.Bold)
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Scrollable process items List
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.weight(1f).testTag("processes_scrolling_list")
            ) {
                items(processes) { (packageName, appName) ->
                    var isKilled by remember(isOptimizing) { mutableStateOf(false) }
                    
                    Card(
                        colors = CardDefaults.cardColors(containerColor = if (isKilled) Color(0xFF131215) else Color(0xFF1C1B1F)),
                        border = BorderStroke(1.dp, Color(0x0FFFFFFF)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.weight(1f)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(32.dp)
                                        .clip(CircleShape)
                                        .background(if (isKilled) Color.DarkGray.copy(alpha = 0.2f) else Color(0xFF00F2FF).copy(alpha = 0.15f)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = if (isKilled) Icons.Default.Block else Icons.Default.Code, 
                                        contentDescription = "Process status", 
                                        tint = if (isKilled) Color.Gray else Color(0xFF00F2FF), 
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Text(
                                        text = appName,
                                        color = if (isKilled) Color.Gray else Color.White,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = packageName,
                                        color = Color.Gray,
                                        fontSize = 8.sp,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }

                            if (!isKilled) {
                                TextButton(
                                    onClick = {
                                        isKilled = true
                                        Toast.makeText(context, "Trimmed background app Standby state.", Toast.LENGTH_SHORT).show()
                                    },
                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                    modifier = Modifier.height(26.dp)
                                ) {
                                    Text("FORCE TRIM", fontSize = 9.sp, color = Color(0xFFFF4B4B), fontWeight = FontWeight.Bold)
                                }
                            } else {
                                Text(
                                    text = "STANDBY",
                                    fontSize = 9.sp,
                                    color = Color.Gray,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 8.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun CircularProgressTile(
    title: String,
    ratio: Float,
    textValue: String,
    color: Color
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier.size(80.dp)
        ) {
            CircularProgressIndicator(
                progress = { ratio },
                modifier = Modifier.size(76.dp),
                color = color,
                strokeWidth = 5.dp,
                trackColor = color.copy(alpha = 0.15f)
            )
            Text(
                text = textValue,
                fontSize = 15.sp,
                color = Color.White,
                fontWeight = FontWeight.Black
            )
        }
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = title,
            fontSize = 9.sp,
            fontWeight = FontWeight.Bold,
            color = Color(0xFF939094)
        )
    }
}
