package com.example.ui.screens

import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.PerformanceProfile
import com.example.ui.viewmodel.BoostixViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfilesScreen(viewModel: BoostixViewModel) {
    val context = LocalContext.current
    val profiles by viewModel.allProfiles.collectAsState()
    val activeProfileId by viewModel.activeProfileId.collectAsState()

    var editingProfile by remember { mutableStateOf<PerformanceProfile?>(null) }
    val scrollState = rememberScrollState()

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
            .padding(16.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(scrollState)
                .padding(bottom = 70.dp) // margin navigation tab bar
        ) {
            Text(
                text = "TUNING DECK",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF00F2FF),
                letterSpacing = 1.5.sp
            )
            Text(
                text = "PERFORMANCE PROFILES",
                fontSize = 22.sp,
                fontWeight = FontWeight.Black,
                color = Color.White,
                modifier = Modifier.padding(bottom = 12.dp)
            )

            profiles.forEach { profile ->
                val isActive = profile.id == activeProfileId
                ProfileCard(
                    profile = profile,
                    isActive = isActive,
                    onActivate = {
                        viewModel.applyProfile(profile.id)
                        Toast.makeText(context, "'${profile.name}' system parameters applied.", Toast.LENGTH_SHORT).show()
                    },
                    onCustomize = { editingProfile = profile }
                )
                Spacer(modifier = Modifier.height(10.dp))
            }
        }
    }

    // Modal Sheet or dialog overlay to customize parameters
    editingProfile?.let { profile ->
        var customBrightness by remember { mutableFloatStateOf(profile.brightnessLevel) }
        var autoDnd by remember { mutableStateOf(profile.dndEnabled) }
        var autoLockRotation by remember { mutableStateOf(profile.autoLockRotation) }
        var autoOptimize by remember { mutableStateOf(profile.autoOptimize) }
        var customRefreshIndex by remember { mutableStateOf(when(profile.customRefreshRate) { 60 -> 1; 90 -> 2; 120 -> 3; else -> 0 }) }

        androidx.compose.ui.window.Dialog(onDismissRequest = { editingProfile = null }) {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1C1B1F)),
                shape = RoundedCornerShape(20.dp),
                border = BorderStroke(1.dp, Color(0x33FFFFFF)),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(12.dp)
            ) {
                Column(
                    modifier = Modifier
                        .padding(20.dp)
                        .verticalScroll(rememberScrollState())
                ) {
                    Text(
                        text = "CUSTOMISE PERFORMANCE PROFILE",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF00F2FF),
                        letterSpacing = 1.sp,
                        modifier = Modifier.padding(bottom = 4.dp)
                    )
                    Text(
                        text = profile.name,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Black,
                        color = Color.White,
                        modifier = Modifier.padding(bottom = 12.dp)
                    )

                    HorizontalDivider(color = Color(0x1AFFFFFF), modifier = Modifier.padding(bottom = 12.dp))

                    // Parameter: Custom Brightness Slider
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Profile Brightness Lock", fontSize = 12.sp, color = Color.White, fontWeight = FontWeight.SemiBold)
                        Text(
                            text = if (customBrightness < 0f) "Don't Change" else "${(customBrightness * 100).toInt()}%",
                            fontSize = 11.sp,
                            color = Color(0xFF00F2FF)
                        )
                    }
                    Slider(
                        value = if (customBrightness < 0f) 0f else customBrightness,
                        onValueChange = { customBrightness = it },
                        modifier = Modifier.fillMaxWidth(),
                        colors = SliderDefaults.colors(
                            thumbColor = Color(0xFF00F2FF),
                            activeTrackColor = Color(0xFF00F2FF),
                            inactiveTrackColor = Color(0x1AFFFFFF)
                        )
                    )
                    Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                        TextButton(onClick = { customBrightness = -1f }, contentPadding = PaddingValues(0.dp)) {
                            Text("Inherit system standard dynamic brightness", fontSize = 10.sp, color = Color(0xFF939094))
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Parameter: Refresh Rate Choice
                    Text("Target Screen Frame Rate", fontSize = 12.sp, color = Color.White, fontWeight = FontWeight.SemiBold)
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        listOf("Default", "60 Hz", "90 Hz", "120 Hz").forEachIndexed { index, rate ->
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(if (customRefreshIndex == index) Color(0xFF303030) else Color(0xFF2C2B2F))
                                    .border(1.dp, if (customRefreshIndex == index) Color(0xFF00F2FF) else Color(0x1AFFFFFF), RoundedCornerShape(8.dp))
                                    .clickable { customRefreshIndex = index }
                                    .padding(vertical = 8.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(rate, fontSize = 10.sp, fontWeight = FontWeight.SemiBold, color = if (customRefreshIndex == index) Color(0xFF00F2FF) else Color.White)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Toggle parameters
                    ToggleItemRow(label = "Enable Do Not Disturb (DND) status", value = autoDnd) { autoDnd = it }
                    ToggleItemRow(label = "Enforce Rotation constraints", value = autoLockRotation) { autoLockRotation = it }
                    ToggleItemRow(label = "Trigger automatic Garbage trim routines", value = autoOptimize) { autoOptimize = it }

                    Spacer(modifier = Modifier.height(20.dp))

                    // Buttons
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End
                    ) {
                        TextButton(onClick = { editingProfile = null }) {
                            Text("DISMISS", color = Color(0xFF939094))
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Button(
                            onClick = {
                                val rateToSave = when(customRefreshIndex) {
                                    1 -> 60
                                    2 -> 90
                                    3 -> 120
                                    else -> -1
                                }
                                viewModel.updateProfileSettings(
                                    profile.copy(
                                        brightnessLevel = customBrightness,
                                        customRefreshRate = rateToSave,
                                        dndEnabled = autoDnd,
                                        autoLockRotation = autoLockRotation,
                                        autoOptimize = autoOptimize
                                    )
                                )
                                editingProfile = null
                                Toast.makeText(context, "${profile.name} updated successfully.", Toast.LENGTH_SHORT).show()
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00F2FF), contentColor = Color.Black)
                        ) {
                            Text("SAVE PRESET", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ProfileCard(
    profile: PerformanceProfile,
    isActive: Boolean,
    onActivate: () -> Unit,
    onCustomize: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(
            containerColor = Color(0xFF1C1B1F)
        ),
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(
            width = 1.dp,
            color = if (isActive) Color(0xFF00F2FF) else Color(0x0FFFFFFF)
        ),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("profile_card_${profile.id}")
    ) {
        Column(
            modifier = Modifier.padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(32.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(
                                when (profile.id) {
                                    "extreme" -> Color(0xFFFF3366).copy(alpha = 0.15f)
                                    "performance" -> Color(0xFFFF9F0A).copy(alpha = 0.15f)
                                    "battery" -> Color(0xFF34D399).copy(alpha = 0.15f)
                                    else -> Color(0xFF00F2FF).copy(alpha = 0.15f)
                                }
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = when (profile.id) {
                                "extreme" -> Icons.Default.Cyclone
                                "performance" -> Icons.Default.Speed
                                "battery" -> Icons.Default.Eco
                                else -> Icons.Default.Tune
                            },
                            contentDescription = "Profile Icon",
                            tint = when (profile.id) {
                                "extreme" -> Color(0xFFFF3366)
                                "performance" -> Color(0xFFFF9F0A)
                                "battery" -> Color(0xFF34D399)
                                else -> Color(0xFF00F2FF)
                            },
                            modifier = Modifier.size(18.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = profile.name,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }

                if (isActive) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(30.dp))
                            .background(Color(0xFF00F2FF).copy(alpha = 0.15f))
                            .padding(horizontal = 8.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = "ACTIVE",
                            fontSize = 8.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF00F2FF)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = profile.description,
                fontSize = 11.sp,
                color = Color(0xFF939094),
                lineHeight = 15.sp
            )

            Spacer(modifier = Modifier.height(14.dp))

            // Spec badges
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                SpecBadge(label = "DND", active = profile.dndEnabled, icon = Icons.Default.DoNotDisturbOn)
                SpecBadge(
                    label = if (profile.brightnessLevel >= 0f) "BRIGHT: ${(profile.brightnessLevel * 100).toInt()}%" else "BRIGHT: AUTO",
                    active = profile.brightnessLevel >= 0,
                    icon = Icons.Default.BrightnessMedium
                )
                SpecBadge(
                    label = if (profile.customRefreshRate > 0) "${profile.customRefreshRate}Hz" else "AUTO Hz",
                    active = profile.customRefreshRate > 0,
                    icon = Icons.Default.Refresh
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End
            ) {
                OutlinedButton(
                    onClick = onCustomize,
                    border = BorderStroke(1.dp, Color(0x33FFFFFF)),
                    shape = RoundedCornerShape(10.dp),
                    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp),
                    modifier = Modifier.height(34.dp).testTag("profile_settings_${profile.id}")
                ) {
                    Text("CONFIGURE", fontSize = 10.sp, color = Color.White)
                }
                Spacer(modifier = Modifier.width(10.dp))
                if (!isActive) {
                    Button(
                        onClick = onActivate,
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00F2FF), contentColor = Color.Black),
                        shape = RoundedCornerShape(10.dp),
                        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp),
                        modifier = Modifier.height(34.dp).testTag("profile_apply_${profile.id}")
                    ) {
                        Text("APPLY SYSTEM", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
fun SpecBadge(label: String, active: Boolean, icon: androidx.compose.ui.graphics.vector.ImageVector) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(6.dp))
            .background(if (active) Color(0xFF303030) else Color(0xFF2C2B2F))
            .border(1.dp, if (active) Color(0x33FFFFFF) else Color(0x0FFFFFFF), RoundedCornerShape(6.dp))
            .padding(horizontal = 6.dp, vertical = 4.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(imageVector = icon, contentDescription = label, tint = if (active) Color(0xFF00F2FF) else Color(0xFF939094), modifier = Modifier.size(10.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = label,
                fontSize = 8.sp,
                fontWeight = FontWeight.SemiBold,
                color = if (active) Color.White else Color(0xFF939094)
            )
        }
    }
}
