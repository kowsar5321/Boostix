package com.example.ui.screens

import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.viewmodel.BoostixViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(viewModel: BoostixViewModel) {
    val context = LocalContext.current
    val scrollState = rememberScrollState()

    // Logs flow
    val logs by viewModel.allLogs.collectAsState()

    // Config states
    var amoledThemeActive by remember { mutableStateOf(true) }
    var autoCleanRAMInterval by remember { mutableStateOf(false) }
    var backupStatusText by remember { mutableStateOf("No local backup file processed.") }

    val df = remember { SimpleDateFormat("HH:mm:ss", Locale.getDefault()) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
            .padding(16.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(scrollState)
                .padding(bottom = 70.dp) // margin navigation tab bar
        ) {
            Text(
                text = "PREFERENCES",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF00F2FF),
                letterSpacing = 1.5.sp
            )
            Text(
                text = "CONTROL DECK",
                fontSize = 22.sp,
                fontWeight = FontWeight.Black,
                color = Color.White,
                modifier = Modifier.padding(bottom = 12.dp)
            )

            // Section 1: Visual Theme Toggle
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1C1B1F)),
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, Color(0x0FFFFFFF)),
                modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Visual Environment", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(top = 10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("AMOLED Midnight Black", fontSize = 12.sp, color = Color.LightGray)
                            Text("Maximizes battery conservation on high-contrast OLED screen layouts.", fontSize = 10.sp, color = Color(0xFF939094))
                        }
                        Switch(
                            checked = amoledThemeActive,
                            onCheckedChange = {
                                amoledThemeActive = it
                                Toast.makeText(context, "AMOLED skin applied universally.", Toast.LENGTH_SHORT).show()
                            },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = Color(0xFF00F2FF),
                                checkedTrackColor = Color(0xFF00F2FF).copy(alpha = 0.3f),
                                uncheckedThumbColor = Color(0xFF939094),
                                uncheckedTrackColor = Color(0xFF2C2B2F)
                            )
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Section 2: Automation Rules
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1C1B1F)),
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, Color(0x0FFFFFFF)),
                modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Automations", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(top = 10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Auto Clean Background standbys", fontSize = 12.sp, color = Color.LightGray)
                            Text("Trims duplicate cached packages continuously before system stalls.", fontSize = 10.sp, color = Color(0xFF939094))
                        }
                        Switch(
                            checked = autoCleanRAMInterval,
                            onCheckedChange = {
                                autoCleanRAMInterval = it
                                Toast.makeText(context, "Smart standby automations activated.", Toast.LENGTH_SHORT).show()
                            },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = Color(0xFF00F2FF),
                                checkedTrackColor = Color(0xFF00F2FF).copy(alpha = 0.3f),
                                uncheckedThumbColor = Color(0xFF939094),
                                uncheckedTrackColor = Color(0xFF2C2B2F)
                            )
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Section 3: Backup & Restore configs
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1C1B1F)),
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, Color(0x0FFFFFFF)),
                modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Data Backup Deck", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    Text("Export customized game settings to cloud directories.", fontSize = 11.sp, color = Color(0xFF939094))

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(backupStatusText, fontSize = 11.sp, color = Color(0xFF00F2FF), fontWeight = FontWeight.SemiBold)

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Button(
                            onClick = {
                                backupStatusText = "Backup successfully recorded: file boostix_backup.json saved."
                                Toast.makeText(context, "Saved settings configuration.", Toast.LENGTH_SHORT).show()
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2C2B2F)),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Default.Backup, contentDescription = "Backup", tint = Color(0xFF00F2FF))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("BACKUP PRESETS", fontSize = 9.sp, color = Color.White)
                        }

                        Button(
                            onClick = {
                                backupStatusText = "Restored config successfully from storage template."
                                Toast.makeText(context, "Applied backup parameters.", Toast.LENGTH_SHORT).show()
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2C2B2F)),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Default.RestorePage, contentDescription = "Restore", tint = Color(0xFF34D399))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("RESTORE TEMPLATE", fontSize = 9.sp, color = Color.White)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Section 4: Optimization history logger
            Row(
                modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "OPTIMISATION SESSIONS HISTORY",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White,
                    letterSpacing = 1.sp
                )

                TextButton(
                    onClick = {
                        viewModel.clearLogs()
                        Toast.makeText(context, "System log tables cleared securely.", Toast.LENGTH_SHORT).show()
                    },
                    modifier = Modifier.testTag("clear_history_btn")
                ) {
                    Text("CLEAR ALL", fontSize = 10.sp, color = Color(0xFFFF4B4B), fontWeight = FontWeight.Bold)
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            if (logs.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(110.dp)
                        .border(1.dp, Color(0x0FFFFFFF), RoundedCornerShape(14.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "History database tables are blank. Re-launch games to observe logs here.",
                        textAlign = TextAlign.Center,
                        color = Color(0xFF939094),
                        fontSize = 11.sp,
                        modifier = Modifier.padding(horizontal = 20.dp)
                    )
                }
            } else {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1C1B1F)),
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.dp, Color(0x0FFFFFFF)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(260.dp)
                ) {
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(8.dp)
                            .testTag("logs_database_list"),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(logs) { log ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(Color(0xFF131215))
                                    .padding(10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(24.dp)
                                            .clip(RoundedCornerShape(6.dp))
                                            .background(
                                                when (log.type) {
                                                    "LAUNCH" -> Color(0xFF00F2FF).copy(alpha = 0.15f)
                                                    "BOOST" -> Color(0xFFFF4B4B).copy(alpha = 0.15f)
                                                    else -> Color(0xFF34D399).copy(alpha = 0.15f)
                                                }
                                            ),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = when (log.type) {
                                                "LAUNCH" -> Icons.Default.PlayArrow
                                                "BOOST" -> Icons.Default.Bolt
                                                else -> Icons.Default.Code
                                            },
                                            contentDescription = log.type,
                                            tint = when (log.type) {
                                                "LAUNCH" -> Color(0xFF00F2FF)
                                                "BOOST" -> Color(0xFFFF4B4B)
                                                else -> Color(0xFF34D399)
                                            },
                                            modifier = Modifier.size(14.dp)
                                        )
                                    }

                                    Spacer(modifier = Modifier.width(10.dp))

                                    Column {
                                        Text(
                                            text = log.message,
                                            color = Color.White,
                                            fontSize = 11.sp,
                                            maxLines = 2,
                                            overflow = TextOverflow.Ellipsis,
                                            lineHeight = 14.sp
                                        )
                                        Text(
                                            text = log.type.uppercase(),
                                            color = Color(0xFF939094),
                                            fontSize = 8.sp,
                                            fontWeight = FontWeight.Bold,
                                            modifier = Modifier.padding(top = 2.dp)
                                        )
                                    }
                                }

                                Text(
                                    text = df.format(Date(log.timestamp)),
                                    color = Color(0xFF939094),
                                    fontSize = 8.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(start = 6.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
