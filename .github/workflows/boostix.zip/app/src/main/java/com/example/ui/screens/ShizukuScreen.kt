package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.HelpOutline
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.viewmodel.BoostixViewModel
import com.example.util.ShizukuManager

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ShizukuScreen(viewModel: BoostixViewModel) {
    val context = LocalContext.current
    val scrollState = rememberScrollState()

    // Shizuku states
    val installed by viewModel.shizukuInstalled.collectAsState()
    val running by viewModel.shizukuRunning.collectAsState()
    val authorized by viewModel.shizukuPermissionGranted.collectAsState()
    val simulated by viewModel.shizukuSimulated.collectAsState()

    val adbCommand = "adb shell sh /sdcard/Android/data/moe.shizuku.privileged.api/files/start.sh"

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
            .padding(16.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(scrollState)
                .padding(bottom = 70.dp) // margin navigation tab bar
        ) {
            Text(
                text = "SANDBOX BRIDGE",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF00F2FF),
                letterSpacing = 1.5.sp
            )
            Text(
                text = "SHIZUKU CENTER",
                fontSize = 22.sp,
                fontWeight = FontWeight.Black,
                color = Color.White,
                modifier = Modifier.padding(bottom = 12.dp)
            )

            // Dynamic Central status card
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1C1B1F)),
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(width = 1.dp, color = if (running) Color(0xFF00F2FF) else Color(0xFFFF4B4B)),
                modifier = Modifier.fillMaxWidth().testTag("shizuku_state_card")
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = if (running) Icons.Default.VerifiedUser else Icons.Default.GppBad,
                                contentDescription = "Security Status",
                                tint = if (running) Color(0xFF00F2FF) else Color(0xFFFF4B4B),
                                modifier = Modifier.size(36.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = if (running) "SHIZUKU RUNNING READY" else "SHIZUKU SERVICE DETACHED",
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Black,
                                    color = Color.White
                                )
                                Text(
                                    text = if (simulated) "Active via sandbox simulation mode" else if (running) "Secure binder bridge connected" else "Awaiting background terminal initiation",
                                    fontSize = 11.sp,
                                    color = Color(0xFF939094)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    HorizontalDivider(color = Color(0x1AFFFFFF))

                    Spacer(modifier = Modifier.height(6.dp))

                    // Detail list Status ticks
                    StatusRegistryTile(label = "Application Installed", checked = installed || simulated)
                    StatusRegistryTile(label = "Service Alive (ping tests)", checked = running)
                    StatusRegistryTile(label = "ADB Permissions Granted", checked = authorized || simulated)

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        if (installed && !running) {
                            Button(
                                onClick = { ShizukuManager.launchShizukuApp(context) },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00F2FF), contentColor = Color.Black),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Text("OPEN SHIZUKU", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        } else if (!installed && !simulated) {
                            Button(
                                onClick = {
                                    try {
                                        context.startActivity(ShizukuManager.getPlayStoreIntent())
                                    } catch (e: Exception) {
                                        Toast.makeText(context, "Play Store app was not found.", Toast.LENGTH_SHORT).show()
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2C2B2F), contentColor = Color.White),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Text("INSTALL FROM DIRECTORY", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }

                        if (running && !authorized && !simulated) {
                            Button(
                                onClick = { viewModel.requestShizukuPermission() },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF34D399), contentColor = Color.Black),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Text("REQUEST PERMIT", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Sandbox Simulation Mode block
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1C1B1F)),
                shape = RoundedCornerShape(14.dp),
                border = BorderStroke(1.dp, Color(0x0FFFFFFF)),
                modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
            ) {
                Row(
                    modifier = Modifier.padding(14.dp).fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Demonstration Sandbox Mode", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color.White)
                        Text("Simulates terminal bindings to preview complete premium utilities instantly offline.", fontSize = 11.sp, color = Color(0xFF939094))
                    }
                    Switch(
                        checked = simulated,
                        onCheckedChange = { viewModel.toggleShizukuSimulation(it) },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color(0xFF00F2FF),
                            checkedTrackColor = Color(0xFF00F2FF).copy(alpha = 0.3f),
                            uncheckedThumbColor = Color(0xFF939094),
                            uncheckedTrackColor = Color(0xFF2C2B2F)
                        ),
                        modifier = Modifier.testTag("simulation_switch")
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Troubleshooter guidelines
            Text(
                text = "ADB WIRELESS SETUP TUNING GUIDE",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White,
                letterSpacing = 1.sp,
                modifier = Modifier.padding(vertical = 8.dp)
            )

            TroubleshootStepTile(
                index = "1",
                title = "Unlock developer Options",
                desc = "Go to device Settings -> About phone -> click 'Build Number' 7 times to unlock the hidden Developer panel."
            )
            TroubleshootStepTile(
                index = "2",
                title = "Flick Wireless Debugging",
                desc = "Enter Settings -> System -> Developer options. Scroll and turn on 'Wireless Debugging' while connected to a subnet Wi-Fi loop."
            )
            TroubleshootStepTile(
                index = "3",
                title = "Pair Shizuku Controller",
                desc = "Open Shizuku -> Select 'Pairing' and click 'Developer options'. In system settings, select 'Pair device with pairing code'. Note down the pairing code and register it in Shizuku's notification banner."
            )
            TroubleshootStepTile(
                index = "4",
                title = "Launch direct Service",
                desc = "Flick back to the Shizuku primary application dashboard and tap 'Start'. The background terminal engine will align instantly."
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Shell Terminal code commands
            Text(
                text = "MANUAL ADB CONSOLE COMMAND (PC)",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White,
                letterSpacing = 1.sp,
                modifier = Modifier.padding(vertical = 6.dp)
            )

            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF131215)),
                shape = RoundedCornerShape(10.dp),
                border = BorderStroke(1.dp, Color(0x0FFFFFFF)),
                modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "If wireless debugging lacks response, connect the phone to your computer via USB and paste the following shell script directly in Command Prompt or PowerShell:",
                        fontSize = 11.sp,
                        color = Color(0xFF939094),
                        lineHeight = 15.sp
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(6.dp))
                            .background(Color(0xFF1C1B1F))
                            .border(1.dp, Color(0x1AFFFFFF), RoundedCornerShape(6.dp))
                            .padding(10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = adbCommand,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = Color(0xFF34D399),
                            modifier = Modifier.weight(1f),
                            maxLines = 2
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        IconButton(
                            onClick = {
                                val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                val clip = ClipData.newPlainText("adb command", adbCommand)
                                clipboard.setPrimaryClip(clip)
                                Toast.makeText(context, "Command script copied to clipboard.", Toast.LENGTH_SHORT).show()
                            },
                            modifier = Modifier.size(28.dp).testTag("copy_adb_cmd_btn")
                        ) {
                            Icon(Icons.Default.ContentCopy, contentDescription = "Copy script", tint = Color(0xFF00F2FF), modifier = Modifier.size(16.dp))
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun StatusRegistryTile(label: String, checked: Boolean) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, fontSize = 12.sp, color = Color.LightGray)
        Icon(
            imageVector = if (checked) Icons.Default.CheckCircle else Icons.Default.Cancel,
            contentDescription = "Tick",
            tint = if (checked) Color(0xFF34D399) else Color(0xFFFF4B4B),
            modifier = Modifier.size(16.dp)
        )
    }
}

@Composable
fun TroubleshootStepTile(index: String, title: String, desc: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        verticalAlignment = Alignment.Top
    ) {
        Box(
            modifier = Modifier
                .size(24.dp)
                .clip(CircleShape)
                .background(Color(0xFF1C1B1F))
                .border(1.dp, Color(0xFF00F2FF), CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Text(index, fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color(0xFF00F2FF))
        }

        Spacer(modifier = Modifier.width(12.dp))

        Column {
            Text(title, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(2.dp))
            Text(desc, color = Color(0xFF939094), fontSize = 11.sp, lineHeight = 15.sp)
        }
    }
}
