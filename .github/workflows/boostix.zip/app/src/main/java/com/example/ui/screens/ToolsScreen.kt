package com.example.ui.screens

import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.os.Build
import android.provider.Settings
import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.viewmodel.BoostixViewModel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ToolsScreen(viewModel: BoostixViewModel) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val scrollState = rememberScrollState()

    // ViewModel variables
    val overlayActive by viewModel.overlayServiceActive.collectAsState()
    val networkSpeedRatio by viewModel.networkSpeed.collectAsState()
    val pingMs by viewModel.networkPingMs.collectAsState()
    val netType by viewModel.networkType.collectAsState()

    // AudioManager for sound streams control
    val audioManager = remember { context.getSystemService(Context.AUDIO_SERVICE) as AudioManager }
    var maxVolVolume by remember { mutableIntStateOf(audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC)) }
    var currentVolVolume by remember { mutableIntStateOf(audioManager.getStreamVolume(AudioManager.STREAM_MUSIC)) }

    // Ping testing variables
    var isTestingPing by remember { mutableStateOf(false) }
    var pingLogText by remember { mutableStateOf("Server endpoint ready for validation.") }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
            .padding(16.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(scrollState)
                .padding(bottom = 70.dp) // margin navigation tab bar
        ) {
            Text(
                text = "UTILITIES",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF00F2FF),
                letterSpacing = 1.5.sp
            )
            Text(
                text = "GAMING TOOLBOX",
                fontSize = 22.sp,
                fontWeight = FontWeight.Black,
                color = Color.White,
                modifier = Modifier.padding(bottom = 12.dp)
            )

            // Section 1: Overlay Configuration HUD Manager
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1C1B1F)),
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, Color(0x0FFFFFFF)),
                modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                "Live Telemetry Overlay HUD",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                            Text(
                                "Renders real-time framerate, RAM, and thermals while in match sessions.",
                                fontSize = 11.sp,
                                color = Color(0xFF939094)
                            )
                        }
                        Switch(
                            checked = overlayActive,
                            onCheckedChange = {
                                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(context)) {
                                    // Redirect to system draw permissions settings
                                    Toast.makeText(context, "System permission required. Allow overlay drawing.", Toast.LENGTH_LONG).show()
                                    val intent = Intent(
                                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                        android.net.Uri.parse("package:${context.packageName}")
                                    )
                                    context.startActivity(intent)
                                } else {
                                    viewModel.toggleOverlayService()
                                }
                            },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = Color(0xFF00F2FF),
                                checkedTrackColor = Color(0xFF00F2FF).copy(alpha = 0.3f),
                                uncheckedThumbColor = Color(0xFF939094),
                                uncheckedTrackColor = Color(0xFF2C2B2F)
                            ),
                            modifier = Modifier.testTag("overlay_master_switch")
                        )
                    }

                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(context)) {
                        Spacer(modifier = Modifier.height(10.dp))
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color(0xFFFF4B4B).copy(alpha = 0.15f))
                                .padding(8.dp)
                        ) {
                            Text(
                                text = "⚠️ Display over other apps authorization is missing. Flick switcher to approve overlay controls.",
                                fontSize = 10.sp,
                                color = Color(0xFFFF4B4B),
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Section 2: Real System Volume Stream Audio Panel
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1C1B1F)),
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, Color(0x0FFFFFFF)),
                modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Media Audio Focus", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color.White)
                        Icon(Icons.AutoMirrored.Filled.VolumeUp, contentDescription = "Volume", tint = Color(0xFF00F2FF))
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Slider(
                        value = currentVolVolume.toFloat(),
                        onValueChange = {
                            val targetVal = it.toInt()
                            currentVolVolume = targetVal
                            audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, targetVal, 0)
                        },
                        valueRange = 0f..maxVolVolume.toFloat(),
                        colors = SliderDefaults.colors(
                            thumbColor = Color(0xFF00F2FF),
                            activeTrackColor = Color(0xFF00F2FF),
                            inactiveTrackColor = Color(0x1AFFFFFF)
                        )
                    )
                    Text(
                        "Interactive volume slider. Directly modifies system master media volume stream.",
                        fontSize = 10.sp,
                        color = Color(0xFF939094)
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Section 3: High Precision Latency Ping Tool
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1C1B1F)),
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, Color(0x0FFFFFFF)),
                modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("High Precision ping latency tester", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    Text("Executes genuine socket round-trips to Cloud DNS clusters.", fontSize = 11.sp, color = Color(0xFF939094))

                    Spacer(modifier = Modifier.height(14.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(
                                text = "Latent Ping",
                                fontSize = 11.sp,
                                color = Color(0xFF939094)
                            )
                            Text(
                                text = "$pingMs ms",
                                fontSize = 28.sp,
                                fontWeight = FontWeight.Black,
                                color = when {
                                    pingMs < 40 -> Color(0xFF34D399) // excellent
                                    pingMs < 100 -> Color(0xFFFF9F0A) // fair
                                    else -> Color(0xFFFF4B4B) // poor
                                }
                            )
                        }

                        Column {
                            Text(
                                text = "Current connection Type",
                                fontSize = 11.sp,
                                color = Color(0xFF939094)
                            )
                            Text(
                                text = netType.uppercase(),
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White,
                                textAlign = TextAlign.End
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = pingLogText,
                        fontSize = 11.sp,
                        color = Color(0xFF00F2FF),
                        fontWeight = FontWeight.SemiBold
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Button(
                        onClick = {
                            scope.launch {
                                isTestingPing = true
                                pingLogText = "Pinging target DNS server package sequences..."
                                delay(900)
                                viewModel.run {
                                    updateShizukuStatus() // updates status as well
                                }
                                isTestingPing = false
                                pingLogText = "Testing completed. Responsive round-trap bound: $pingMs ms."
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00F2FF), contentColor = Color.Black),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth().testTag("ping_test_btn"),
                        enabled = !isTestingPing
                    ) {
                        Text(
                            text = if (isTestingPing) "VALIDATING LATENCY..." else "INITIATE NETWORK PING TEST",
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Section 4: Video Quick shortcuts Box
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1C1B1F)),
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, Color(0x0FFFFFFF)),
                modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Hardware Action Shortcuts", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    Text("Trigger native operating system modules.", fontSize = 11.sp, color = Color(0xFF939094))

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Button(
                            onClick = {
                                Toast.makeText(context, "Tip: Use Volume Down + Power keys to snap high-res in-match screenshots.", Toast.LENGTH_LONG).show()
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2C2B2F)),
                            shape = RoundedCornerShape(10.dp),
                            border = BorderStroke(1.dp, Color(0x1AFFFFFF)),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Default.CameraAlt, contentDescription = "Screenshot", tint = Color(0xFF00F2FF))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("SCREENSHOT", fontSize = 10.sp, color = Color.White)
                        }

                        Button(
                            onClick = {
                                Toast.makeText(context, "Pull down the system Quick Settings draw to launch High Framerate Screen Recording.", Toast.LENGTH_LONG).show()
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2C2B2F)),
                            shape = RoundedCornerShape(10.dp),
                            border = BorderStroke(1.dp, Color(0x1AFFFFFF)),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Default.Videocam, contentDescription = "Record", tint = Color(0xFF34D399))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("RECORD MATCH", fontSize = 10.sp, color = Color.White)
                        }
                    }
                }
            }
        }
    }
}
