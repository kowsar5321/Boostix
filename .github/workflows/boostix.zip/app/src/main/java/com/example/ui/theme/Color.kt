package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Clean Minimalism Color Palette
val AmoledBlack = Color(0xFF000000)
val DarkGreyBg = Color(0xFF1C1B1F)
val SlateGreyBg = Color(0xFF2C2B2F)
val MiniPillBg = Color(0xFF303030)

// Vibrant Minimalism Accents
val HighlightCyan = Color(0xFF00F2FF)
val VibrantMint = Color(0xFF34D399)
val NeonOrange = Color(0xFFFF8A00)
val SoftBlueSection = Color(0xFFD1E1FF)
val DeepNavyText = Color(0xFF001D36)

// Base compatibility definitions for standard themes
val DeepObsidian = Color(0xFF121212)
val CardBackground = Color(0xFF1C1B1F)
val CardBackgroundLight = Color(0xFF2C2B2F)

// Color references used across core screens mapped directly to Minimalism
val NeonTeal = Color(0xFF00F2FF)
val NeonCyan = Color(0xFF00F2FF)
val NeonPurple = Color(0xFFE0A0FF)
val NeonPink = Color(0xFFFF4B4B)
val NeonGreen = Color(0xFF34D399)
val NeonAmber = Color(0xFFFF8A00)
val NeonRed = Color(0xFFFF4B4B)

// Texts & Border Colors
val TextPrimary = Color(0xFFE3E2E6)
val TextSecondary = Color(0xFF939094)
val BorderColor = Color(0xFF2C2B2F)
val BorderGlowing = Color(0xFF00F2FF)

