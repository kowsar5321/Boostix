package com.example.ui.viewmodel

import android.app.Application
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.os.Build
import android.provider.Settings
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.Game
import com.example.data.model.LogEntry
import com.example.data.model.PerformanceProfile
import com.example.data.repository.GameRepository
import com.example.service.FloatingMonitorService
import com.example.util.ProcessOptimizer
import com.example.util.ShizukuManager
import com.example.util.SystemMonitor
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class BoostixViewModel(application: Application) : AndroidViewModel(application) {
    private val context = application.applicationContext
    private val repository = GameRepository(context)
    private val systemMonitor = SystemMonitor(context)

    // Repository states
    val allGames: StateFlow<List<Game>> = repository.allGames.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val favoriteGames: StateFlow<List<Game>> = repository.favoriteGames.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val recentlyPlayedGames: StateFlow<List<Game>> = repository.recentlyPlayedGames.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val allLogs: StateFlow<List<LogEntry>> = repository.allLogs.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val allProfiles: StateFlow<List<PerformanceProfile>> = repository.allProfiles.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    // Shizuku State
    private val _shizukuInstalled = MutableStateFlow(false)
    val shizukuInstalled = _shizukuInstalled.asStateFlow()

    private val _shizukuRunning = MutableStateFlow(false)
    val shizukuRunning = _shizukuRunning.asStateFlow()

    private val _shizukuPermissionGranted = MutableStateFlow(false)
    val shizukuPermissionGranted = _shizukuPermissionGranted.asStateFlow()

    private val _shizukuSimulated = MutableStateFlow(false)
    val shizukuSimulated = _shizukuSimulated.asStateFlow()

    // UI state states
    private val _isOptimizing = MutableStateFlow(false)
    val isOptimizing = _isOptimizing.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery = _searchQuery.asStateFlow()

    private val _allInstalledApps = MutableStateFlow<List<Pair<String, String>>>(emptyList())
    val allInstalledApps = _allInstalledApps.asStateFlow()

    // Live Telemetry states connected from SystemMonitor
    val ramUsage = systemMonitor.ramUsage
    val ramTotalGb = systemMonitor.ramTotalGb
    val ramUsedGb = systemMonitor.ramUsedGb
    val cpuUsage = systemMonitor.cpuUsage
    val storageUsage = systemMonitor.storageUsage
    val storageTotalGb = systemMonitor.storageTotalGb
    val storageFreeGb = systemMonitor.storageFreeGb
    val batteryLevel = systemMonitor.batteryLevel
    val batteryTemp = systemMonitor.batteryTemp
    val deviceTemp = systemMonitor.deviceTemp
    val batteryStatus = systemMonitor.batteryStatus
    val batteryHealth = systemMonitor.batteryHealth
    val networkSpeed = systemMonitor.networkSpeed
    val networkPingMs = systemMonitor.networkPingMs
    val networkType = systemMonitor.networkType
    val activeProcessesCount = systemMonitor.activeProcessesCount

    // Selected central profile configuration
    private val _activeProfileId = MutableStateFlow("balanced")
    val activeProfileId = _activeProfileId.asStateFlow()

    // Overlay active state
    private val _overlayServiceActive = MutableStateFlow(false)
    val overlayServiceActive = _overlayServiceActive.asStateFlow()

    // Deep logging indicator
    private val _statusMessage = MutableStateFlow("System standby. Tap Quick Boost to clean background apps.")
    val statusMessage = _statusMessage.asStateFlow()

    init {
        viewModelScope.launch {
            repository.initializeDatabase()
            updateShizukuStatus()
            systemMonitor.startMonitoring()
            loadInstalledApps()
            checkOverlayStatus()
        }
    }

    override fun onCleared() {
        super.onCleared()
        systemMonitor.stopMonitoring()
    }

    /**
     * Refreshes Shizuku status descriptors.
     */
    fun updateShizukuStatus() {
        _shizukuInstalled.value = ShizukuManager.isShizukuInstalled(context)
        _shizukuRunning.value = ShizukuManager.isShizukuRunning()
        _shizukuPermissionGranted.value = ShizukuManager.hasShizukuPermission()
        _shizukuSimulated.value = ShizukuManager.isSimulated
    }

    /**
     * Toggles manual Shizuku Simulation Mode.
     */
    fun toggleShizukuSimulation(enabled: Boolean) {
        ShizukuManager.isSimulated = enabled
        _shizukuSimulated.value = enabled
        updateShizukuStatus()
        viewModelScope.launch {
            repository.addLog(
                "SHIZUKU", 
                if (enabled) "Shizuku Simulation Mode enabled successfully." 
                else "Shizuku Simulation Mode disabled. Connecting to real interface."
            )
        }
    }

    /**
     * Request Shizuku authority.
     */
    fun requestShizukuPermission() {
        ShizukuManager.requestShizukuPermission(1001) { granted ->
            _shizukuPermissionGranted.value = granted
            viewModelScope.launch {
                repository.addLog(
                    "SHIZUKU", 
                    if (granted) "Shizuku user connection authorized successfully." 
                    else "Shizuku authorization request dismissed/denied."
                )
            }
        }
    }

    /**
     * Runs quick memory cleaner boost.
     */
    fun runQuickBoost() {
        viewModelScope.launch {
            _isOptimizing.value = true
            _statusMessage.value = "Scanning dynamic heaps, releasing memory garbage collections..."
            delay(1500)
            val killed = ProcessOptimizer.triggerBoost(context)
            _isOptimizing.value = false
            _statusMessage.value = "Optimised! Freed $killed background application processes successfully."
        }
    }

    /**
     * Set active profile.
     */
    fun applyProfile(profileId: String) {
        viewModelScope.launch {
            _activeProfileId.value = profileId
            val profile = repository.allProfiles.first().find { it.id == profileId }
            if (profile != null) {
                ProcessOptimizer.applyProfileConfiguration(
                    context,
                    profile.name,
                    profile.brightnessLevel,
                    profile.dndEnabled,
                    profile.autoLockRotation
                )
                _statusMessage.value = "Engine set to: '${profile.name}' is now active."
            }
        }
    }

    /**
     * Set update brightness and other attributes in specific profile
     */
    fun updateProfileSettings(profile: PerformanceProfile) {
        viewModelScope.launch {
            repository.updateProfile(profile)
        }
    }

    /**
     * Change target Game custom configuration.
     */
    fun saveGameSettings(game: Game) {
        viewModelScope.launch {
            repository.updateGame(game)
        }
    }

    /**
     * Launches a game from our grid.
     */
    fun launchGame(packageName: String, title: String, onLaunchRequired: (Intent) -> Unit, onFail: (String) -> Unit) {
        viewModelScope.launch {
            _statusMessage.value = "Applying per-game optimization parameters for '$title'..."
            
            // 1. Fetch customized game settings
            val gamesList = allGames.value
            val game = gamesList.find { it.packageName == packageName }
            
            // 2. Determine boost profile to apply
            val profileToApply = game?.selectedProfileId ?: _activeProfileId.value
            val profile = repository.allProfiles.first().find { it.id == profileToApply }
            
            if (game?.autoOptimize == true && profile != null) {
                // Apply setting params
                ProcessOptimizer.applyProfileConfiguration(
                    context,
                    "Pre-launch: ${profile.name}",
                    if (game.customBrightness >= 0f) game.customBrightness else profile.brightnessLevel,
                    game.autoDnd || profile.dndEnabled,
                    game.autoLockRotation || profile.autoLockRotation
                )
                
                // Extra memory clean boost right before launch
                ProcessOptimizer.triggerBoost(context)
            }

            delay(1000)

            // 3. Trigger actual launch intent
            val pm = context.packageManager
            val intent = pm.getLaunchIntentForPackage(packageName)
            if (intent != null) {
                repository.launchGame(packageName, title)
                onLaunchRequired(intent)
                _statusMessage.value = "Active game session launched successfully for '$title'."
            } else {
                onFail("Failed to retrieve system launch intent for '$title'.")
                repository.addLog("LAUNCH", "Launch failed: No launch Intent found for package $packageName")
            }
        }
    }

    /**
     * Toggles overlay service.
     */
    fun toggleOverlayService() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(context)) {
            // Can't automatically show, client must permit
            _statusMessage.value = "Overlay permission missing. Please authorize overlay drawing in settings."
            return
        }

        val intent = Intent(context, FloatingMonitorService::class.java)
        if (_overlayServiceActive.value) {
            context.stopService(intent)
            _overlayServiceActive.value = false
        } else {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
            _overlayServiceActive.value = true
        }
    }

    fun checkOverlayStatus() {
        _overlayServiceActive.value = FloatingMonitorService.isServiceRunning
    }

    /**
     * Toggle favorite game space constraint.
     */
    fun toggleGameFavorite(packageName: String) {
        viewModelScope.launch {
            val game = allGames.value.find { it.packageName == packageName }
            if (game != null) {
                repository.updateGame(game.copy(isFavorite = !game.isFavorite))
            }
        }
    }

    /**
     * Scan applications to populate full game listings manually.
     */
    fun scanAndRefreshGames() {
        viewModelScope.launch {
            _isOptimizing.value = true
            _statusMessage.value = "Scanning local system folders for game components..."
            delay(1200)
            repository.scanAndPopulateGames()
            _isOptimizing.value = false
            _statusMessage.value = "Refreshed game listings! System scan complete."
        }
    }

    /**
     * Add manual package label.
     */
    fun addInstalledAppAsGame(packageName: String, label: String) {
        viewModelScope.launch {
            repository.addAppAsGame(packageName, label)
        }
    }

    /**
     * Clear telemetry history log list.
     */
    fun clearLogs() {
        viewModelScope.launch {
            repository.clearLogs()
        }
    }

    fun updateSearchQuery(query: String) {
        _searchQuery.value = query
    }

    private suspend fun loadInstalledApps() = withContext(Dispatchers.IO) {
        try {
            val pm = context.packageManager
            val installed = pm.getInstalledApplications(PackageManager.GET_META_DATA)
            val filtered = installed.map { app ->
                app.packageName to app.loadLabel(pm).toString()
            }.sortedBy { it.second }
            _allInstalledApps.value = filtered
        } catch (e: Exception) {
            Log.e("ViewModel", "App load error: ${e.message}")
        }
    }

    fun getAppIcon(packageName: String) = repository.getAppIcon(packageName)
}
