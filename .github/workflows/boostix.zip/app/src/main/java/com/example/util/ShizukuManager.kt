package com.example.util

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.util.Log

object ShizukuManager {
    private const val TAG = "ShizukuManager"
    const val SHIZUKU_PACKAGE_NAME = "moe.shizuku.privileged.api"

    // Simulation mode for environments without a running Shizuku service.
    // Extremely useful for styling testing and visual previews!
    var isSimulated: Boolean = false

    /**
     * Checks if Shizuku app is installed on this device.
     */
    fun isShizukuInstalled(context: Context): Boolean {
        return try {
            context.packageManager.getPackageInfo(SHIZUKU_PACKAGE_NAME, 0)
            true
        } catch (e: PackageManager.NameNotFoundException) {
            false
        }
    }

    /**
     * Checks if the active Shizuku system service is running.
     * In real devices, we check Shizuku.pingBinder() via reflection or linking library.
     * Here, we do a dynamic reflective check of the Shizuku class, with simulated fallbacks.
     */
    fun isShizukuRunning(): Boolean {
        if (isSimulated) return true
        return try {
            val shizukuClass = Class.forName("moe.shizuku.api.Shizuku")
            val pingMethod = shizukuClass.getMethod("pingBinder")
            val result = pingMethod.invoke(null) as? Boolean ?: false
            result
        } catch (e: Exception) {
            Log.d(TAG, "Shizuku binder is not available or not running.")
            false
        }
    }

    /**
     * Checks if this application has Shizuku authorization.
     */
    fun hasShizukuPermission(): Boolean {
        if (isSimulated) return true
        return try {
            val shizukuClass = Class.forName("moe.shizuku.api.Shizuku")
            val checkMethod = shizukuClass.getMethod("checkPermission")
            val result = checkMethod.invoke(null) as? Int ?: PackageManager.PERMISSION_DENIED
            result == PackageManager.PERMISSION_GRANTED
        } catch (e: Exception) {
            false
        }
    }

    /**
     * Requests permission from Shizuku.
     */
    fun requestShizukuPermission(requestCode: Int, callback: (Boolean) -> Unit) {
        if (isSimulated) {
            callback(true)
            return
        }
        try {
            val shizukuClass = Class.forName("moe.shizuku.api.Shizuku")
            val requestClass = Class.forName("moe.shizuku.api.Shizuku\$OnRequestPermissionResultListener")
            
            // On a real device, if we can't request directly via official api class:
            val requestMethod = shizukuClass.getMethod("requestPermission", Int::class.javaPrimitiveType)
            requestMethod.invoke(null, requestCode)
            
            // Post a delay just in case Shizuku fails to spawn dialog
            Handler(Looper.getMainLooper()).postDelayed({
                callback(hasShizukuPermission())
            }, 1000)
        } catch (e: Exception) {
            Log.e(TAG, "Unable to request Shizuku permission reflectively: ${e.message}")
            callback(false)
        }
    }

    /**
     * Launches the Shizuku app if installed.
     */
    fun launchShizukuApp(context: Context): Boolean {
        return try {
            val intent = context.packageManager.getLaunchIntentForPackage(SHIZUKU_PACKAGE_NAME)
            if (intent != null) {
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(intent)
                true
            } else {
                false
            }
        } catch (e: Exception) {
            false
        }
    }

    /**
     * Returns the play store link to install Shizuku.
     */
    fun getPlayStoreIntent(): Intent {
        return Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=$SHIZUKU_PACKAGE_NAME")).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
    }
}
